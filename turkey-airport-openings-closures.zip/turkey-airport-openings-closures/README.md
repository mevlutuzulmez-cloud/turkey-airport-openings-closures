# Airport openings and temporary closures in Türkiye, 2010–2026: replication data and code

Replication package for:

> Üzülmez, M. (2026). Do new regional airports steal passengers? Evidence from airport openings and temporary closures in Türkiye. *Manuscript submitted to the Journal of Air Transport Management.*

The package contains:

- a monthly airport-level traffic panel for all 58 airports reported by DHMİ (State Airports Authority of Türkiye), January 2009–October 2026, rebuilt from 214 monthly statistical workbooks;
- road travel times between all airport pairs;
- the event definitions (8 airport openings, 7 analysed temporary closures);
- the full Python code that produces every table and figure in the article.

## Contents

```
code/      Python scripts (run order below)
data/      processed panel, distance matrices, event definitions
output/    estimation results (CSV) as used in the article
figures/   figures as used in the article (PNG, 600 dpi)
```

### The panel: `data/panel_airport_month.csv`

One row per airport and month. The columns are:

| Column | Description |
|---|---|
| `code` | IATA code (`ISL` = Istanbul Atatürk, `IST` = Istanbul Airport) |
| `year`, `month`, `date` | Calendar month |
| `pax_dom`, `pax_intl`, `pax_total` | Passengers (arriving + departing): domestic, international, total |
| `com_atm_dom`, `com_atm_intl`, `com_atm_total` | Commercial aircraft movements |
| `all_atm_*` | All aircraft movements |
| `freight_*` | Freight incl. baggage and mail (tonnes) |
| `cargo_*` | Cargo (tonnes; not reported in every year) |

**How the panel is built.** DHMİ reports cumulative year-to-date figures, and monthly values are differences between consecutive months. Where a later workbook reports a revised figure for the previous year, the revised figure is used. Three corrections are applied:

- blank cells are treated as zero;
- two stale workbooks (July 2010 and September 2012), which repeat the previous month's figures, are detected automatically and replaced by the other workbook that reports those months;
- the 2009 workbooks are internally inconsistent, so the analysis uses 2010 onwards.

Airport totals reproduce DHMİ's national totals exactly in every year.

### Other data files

| File | Content |
|---|---|
| `data/events.csv` | Openings, analysed closures, small closures used only to exclude contaminated airport-months, excluded hubs and relocations, COVID-19 window |
| `data/road_time_min.csv`, `data/road_dist_km.csv` | OSRM free-flow road travel time (minutes) and distance (km), 58 × 58 |
| `data/dist_greatcircle_km.csv` | Great-circle distances |
| `data/airports_coords.csv` | Airport coordinates (OurAirports) |
| `data/interim_ytd_long.csv` | Parsed cumulative values from every workbook, before conversion to monthly values |
| `data/raw/dhmi_index.json` | URLs of all DHMİ workbooks by year and month |

## Running the code

Requirements: Python 3.14 (tested) and the packages in `requirements.txt`.

```bash
pip install -r requirements.txt
cd code
bash run_all.sh                 # all estimates, tables and figures from the processed data
bash run_all.sh --from-source   # additionally re-download DHMİ workbooks and rebuild panel and distances
```

A full run takes roughly one to two hours on a laptop. Most of the time goes to the placebo and bootstrap steps in `13_revision.py`.

| Script | Purpose |
|---|---|
| `00_list_dhmi.py`, `01_download_dhmi.py` | List and download the DHMİ monthly workbooks |
| `02_parse_raw.py`, `03_build_panel.py` | Parse the workbooks and build the monthly panel |
| `00b_download_aux.py` | Download OurAirports and Natural Earth files |
| `04_distances.py` | Coordinates and OSRM road travel times (uses the public OSRM demo server) |
| `common.py` | Event definitions, stack construction |
| `05_main.py` | Stacked difference-in-differences, event studies, randomisation inference |
| `06_sdid.py`, `sdid.py` | Synthetic difference-in-differences by stack |
| `07_robustness.py`, `08_placebo_checks.py`, `09_trend_break.py` | Robustness, time placebos, trend-break models |
| `13_revision.py` | Imputation estimator in levels, persistence after reopening, flights decomposition, placebo airports, wild cluster bootstrap, sample variants |
| `10_tables_figures.py`, `14_figures_v2.py` | Tables and figures |

## Correspondence with the article

| Article | File(s) |
|---|---|
| Table 1 | `output/table1_events.csv` |
| Table 2 | `output/table2_pooled.csv`, `output/rev_wild_bootstrap.csv` |
| Table 3 | `output/rev_impute_main.csv`, `output/rev_flights_decomposition.csv` |
| Table 4 | `output/table5_distance_bands.csv` |
| Table 5 | `output/rev_summary_ratios.csv` |
| Table 6 | `output/table4_robustness.csv` |
| Table A1 | `output/rev_units_main.csv` |
| Table A2 | `output/table3_stacks.csv`, `output/sdid_by_stack.csv` |
| Fig. 1 | `figures/fig1_map.png` |
| Fig. 2 | `figures/figA_network_growth.png` |
| Fig. 3 | `figures/figB_closure_anatomy.png` |
| Fig. 4 | `figures/figC_opening_anatomy.png` |
| Fig. 5 | `figures/fig2_event_studies.png` |
| Fig. 6 | `figures/figD_flow_map.png` |
| Fig. 7 | `figures/fig5_distance.png` |
| Fig. 8 | `figures/figE_capacity_vs_passengers.png` |
| Fig. 9 | `figures/figF_persistence.png` |
| Fig. 10 | `figures/figG_summary_ratios.png` |

Some CSV names follow the order of an earlier draft; the table above is authoritative. `10_tables_figures.py` also writes two figures (`fig3_ratios.png`, `fig4_series.png`) that the final article does not use.

## Notes

- Randomised steps (randomisation inference, placebo airports, bootstrap) use fixed seeds, so reruns reproduce the reported numbers up to library-version differences.
- Road travel times are free-flow car times on the OpenStreetMap network at the time of computation (2026). They are used to rank airport pairs by proximity.

## Licence and citation

The code is released under the MIT License. The data terms are listed in `DATA_LICENSE.md`: processed data are released under CC BY 4.0 with attribution to DHMİ, and road times are under ODbL (© OpenStreetMap contributors). Please cite the article and this repository (see `CITATION.cff`).

Contact: Mevlüt Üzülmez, Erciyes University, mevlutuzulmez@erciyes.edu.tr, ORCID 0000-0002-4606-7468
