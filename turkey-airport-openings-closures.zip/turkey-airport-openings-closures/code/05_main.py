"""Main estimates: stacked difference-in-differences for airport openings and temporary closures,
airport-level effects with placebo-based inference, diversion share (openings) and recapture
rate (closures), pooled event study."""
import warnings
import numpy as np, pandas as pd, pyfixest as pf
from common import *
warnings.filterwarnings("ignore")
RNG = np.random.default_rng(20261114)
P, T = load_panel(), road_time()


def opening_groups():
    g = {}
    for j, d in OPENINGS:
        g.setdefault(pd.Timestamp(d), []).append(j)
    return g


def stacks(kind, events=None, **kw):
    out = []
    if kind == "opening":
        for d, fs in opening_groups().items():
            if events and not set(fs) & set(events): continue
            out.append(build_stack(fs, d, None, "opening", P, T, **kw))
    else:
        for j, a, b in CLOSURES:
            if events and j not in events: continue
            out.append(build_stack([j], pd.Timestamp(a), pd.Timestamp(b), "closure", P, T, **kw))
    return [s for s in out if s.treated.sum() > 0]


def fit(d, rhs="D", vcov=None):
    d = add_fe_ids(d)
    return pf.feols(f"y ~ {rhs} | fe_unit + fe_time + fe_season", data=d, vcov=vcov or {"CRV1": "code"})


def ri_pvalue(d, coef, n=500):
    """Randomisation inference: reassign treatment among all airports within each stack."""
    d = d.copy(); stats = []
    for _ in range(n):
        d["Dp"] = 0
        for st, g in d.groupby("stack"):
            codes = g.code.unique(); k = g[g.treated == 1].code.nunique()
            pick = RNG.choice(codes, size=k, replace=False)
            m = (d["stack"] == st) & d.code.isin(pick) & (d.post == 1)
            d.loc[m, "Dp"] = 1
        stats.append(fit(d, "Dp", vcov="iid").coef().iloc[0])
    stats = np.array(stats)
    return (np.abs(stats) >= abs(coef)).mean(), stats


def pooled(kind, ri=0, **kw):
    S = stacks(kind, **kw)
    d = pd.concat(S)
    m = fit(d)
    t = m.tidy().loc["D"]
    r = dict(kind=kind, coef=t.Estimate, se=t["Std. Error"], p=t["Pr(>|t|)"], n_stacks=len(S),
             n_treated=d[d.treated == 1].drop_duplicates(["stack", "code"]).shape[0],
             n_control=d[d.treated == 0].drop_duplicates(["stack", "code"]).shape[0], nobs=m._N)
    if ri:
        r["p_ri"], _ = ri_pvalue(d, t.Estimate, n=ri)
    return r, d


def usable_treated(g):
    cnt = g[g.treated == 1].groupby("code").post.agg(["sum", "size"])
    return sorted(cnt[(cnt["sum"] >= 2) & (cnt["size"] - cnt["sum"] >= 6)].index)


def unit_and_placebo(g):
    """Effects of each treated airport (one regression per stack) and placebo effects obtained by
    treating, one at a time, each control airport as if it were exposed (treated airports dropped)."""
    tr = usable_treated(g)
    g = g[(g.treated == 0) | g.code.isin(tr)].copy()
    for c in tr:
        g[f"D_{c}"] = ((g.code == c) & (g.post == 1)).astype(int)
    m = fit(g, " + ".join(f"D_{c}" for c in tr))
    beta = m.coef()[[f"D_{c}" for c in tr]]
    ctrl = g[g.treated == 0].copy()
    plc = []
    for c in ctrl.code.unique():
        ctrl["Dp"] = ((ctrl.code == c) & (ctrl.post == 1)).astype(int)
        if ctrl.Dp.sum() < 2 or (ctrl[ctrl.code == c].post == 0).sum() < 6: continue
        plc.append(fit(ctrl, "Dp", vcov="iid").coef().iloc[0])
    return g, tr, beta, np.array(plc)


def stack_transfer(kind, d, nperm=500):
    """Stack-level effect (common to all exposed airports in the stack), passengers moved and
    ratio. Inference: placebo stacks in which k randomly chosen control airports are labelled
    exposed (k = number of exposed airports), giving the null distribution of the stack effect."""
    res = []
    for st, g in d.groupby("stack"):
        tr = usable_treated(g)
        if not tr: continue
        g = g[(g.treated == 0) | g.code.isin(tr)].copy()
        b = fit(g).coef().iloc[0]
        ctrl = g[g.treated == 0].copy()
        cc = ctrl.groupby("code").post.agg(["sum", "size"])
        codes = cc[(cc["sum"] >= 2) & (cc["size"] - cc["sum"] >= 6)].index.values
        k = min(len(tr), len(codes) // 2)
        plc = []
        for _ in range(nperm):
            pick = RNG.choice(codes, size=k, replace=False)
            ctrl["D"] = (ctrl.code.isin(pick) & (ctrl.post == 1)).astype(int)
            plc.append(fit(ctrl, vcov="iid").coef().iloc[0])
        plc = np.array(plc)
        focals = st.split("-")[0].split("+")
        post = g[(g.treated == 1) & (g.post == 1)]
        months = sorted(post.date.unique())
        y1 = post.pax_dom.sum()
        mv = lambda bb: y1 * (np.exp(-bb) - 1) if np.isscalar(bb) else y1 * (np.exp(-bb) - 1)
        sims = mv(b + (plc - plc.mean()))
        if kind == "opening":
            base = P[P.code.isin(focals) & P.date.isin(months)].pax_dom.sum(); point = mv(b)
        else:
            cf = closed_counterfactual(focals[0], months, g)
            base = cf - P[(P.code == focals[0]) & P.date.isin(months)].pax_dom.sum()
            point, sims = -mv(b), -sims
        res.append(dict(stack=st, kind=kind, airports=",".join(tr), n_exposed=len(tr), n_control=len(codes),
                        months=len(months), coef=b, se_placebo=plc.std(ddof=1),
                        p_placebo=(np.abs(plc) >= abs(b)).mean(), exposed_pax=y1, focal_pax=base,
                        moved=point, ratio=point / base,
                        ci_lo=np.percentile(sims / base, 2.5), ci_hi=np.percentile(sims / base, 97.5)))
    return pd.DataFrame(res)


def transfers(kind, d, ndraw=4000):
    res, units = [], []
    for st, g in d.groupby("stack"):
        if not usable_treated(g):
            print("  no usable treated airports in", st); continue
        g, tr, beta, plc = unit_and_placebo(g)
        sd = plc.std(ddof=1)
        focals = st.split("-")[0].split("+")
        post = g[(g.treated == 1) & (g.post == 1)]
        months = sorted(post.date.unique())
        vals = [post[post.code == c].pax_dom.values for c in tr]
        def moved(b):                                   # counterfactual minus actual, per airport
            return np.array([(v * (np.exp(-bb) - 1)).sum() for v, bb in zip(vals, b)])
        point = moved(beta.values)
        # uncertainty: each airport effect perturbed by an independent draw from the placebo distribution
        draws = beta.values[None, :] + RNG.choice(plc - plc.mean(), size=(ndraw, len(tr)))
        sims = np.array([moved(b).sum() for b in draws])
        for c, b, pt in zip(tr, beta.values, point):
            pre_mean = g[(g.code == c) & (g.post == 0)].pax_dom.mean()
            units.append(dict(stack=st, kind=kind, code=c, rt=g[g.code == c].rt.iloc[0], pre_mean=pre_mean,
                              coef=b, se_placebo=sd, p_placebo=(np.abs(plc) >= abs(b)).mean(),
                              n_placebo=len(plc), pax_moved=-pt))
        if kind == "opening":
            base = P[P.code.isin(focals) & P.date.isin(months)].pax_dom.sum()
            res.append(dict(stack=st, months=len(months), airports=",".join(tr), focal_pax=base,
                            moved=point.sum(), ratio=point.sum() / base,
                            ci_lo=np.percentile(sims / base, 2.5), ci_hi=np.percentile(sims / base, 97.5)))
        else:
            j = focals[0]
            cf = closed_counterfactual(j, months, g)
            lost = cf - P[(P.code == j) & P.date.isin(months)].pax_dom.sum()
            res.append(dict(stack=st, months=len(months), airports=",".join(tr), focal_pax=lost,
                            moved=-point.sum(), ratio=-point.sum() / lost,
                            ci_lo=np.percentile(-sims / lost, 2.5), ci_hi=np.percentile(-sims / lost, 97.5)))
    return pd.DataFrame(res), pd.DataFrame(units)


def closed_counterfactual(j, months, g):
    """Passengers the closed airport would have handled: same calendar month one year earlier
    (earlier years if that month was also closed) times the growth of the stack's control airports."""
    ctrl = g[g.treated == 0]
    tot = 0.0
    for m in months:
        for lag in (12, 24, 36):
            m0 = m - pd.DateOffset(months=lag)
            y0 = P[(P.code == j) & (P.date == m0)].pax_dom.sum()
            if y0 > 0: break
        c1 = ctrl[ctrl.date == m].set_index("code").pax_dom
        c0 = P[(P.date == m0) & P.code.isin(c1.index)].set_index("code").pax_dom
        common = c1.index.intersection(c0[c0 > 0].index)
        tot += y0 * c1[common].sum() / c0[common].sum()
    return tot


def seasonal_adjust(d):
    """Remove each airport's month-of-year profile estimated on its own pre-event months only."""
    d = d.copy()
    pre = d[d.date < d.groupby("stack").apply(lambda g: g[g.post == 1].date.min()).reindex(d["stack"]).values]
    s = pre.groupby(["stack", "code", "moy"]).y.mean().rename("s")
    d = d.join(s, on=["stack", "code", "moy"])
    d["y"] = d.y - d.s
    return d.dropna(subset=["y"])


def event_study(d, kind):
    """Event-time coefficients. Unit x month-of-year effects are collinear with event-time bins, so the
    outcome is seasonally adjusted with pre-event month-of-year means and the model has unit and
    stack-time effects only."""
    d = seasonal_adjust(d)
    if kind == "opening":
        d["bin"] = np.floor(d.rel / 3).astype(int).clip(-16, 7)       # quarters, ref = -1
    else:
        d["bin"] = d.rel.clip(-12, 5)                                 # months, ref = -1
    ref = -1
    have = set(d[d.treated == 1].bin.unique())
    bins = sorted(b for b in d.bin.unique() if b != ref and b in have)
    nm = lambda b: f"ev_{'m' if b < 0 else 'p'}{abs(b)}"
    for b in bins:
        d[nm(b)] = ((d.bin == b) & (d.treated == 1)).astype(int)
    dd = add_fe_ids(d)
    m = pf.feols("y ~ " + " + ".join(nm(b) for b in bins) + " | fe_unit + fe_time", data=dd, vcov={"CRV1": "code"})
    t = m.tidy().reindex([nm(b) for b in bins])
    out = pd.DataFrame(dict(bin=bins, coef=t["Estimate"].values, se=t["Std. Error"].values))
    return pd.concat([out, pd.DataFrame(dict(bin=[ref], coef=[0.0], se=[0.0]))]).sort_values("bin")


if __name__ == "__main__":
    pd.set_option("display.width", 220)
    summ = []
    for kind in ["opening", "closure"]:
        for outc in ["pax_dom", "pax_total"]:
            r, d = pooled(kind, outcome=outc, ri=300 if outc == "pax_dom" else 0)
            r["outcome"] = outc; summ.append(r)
            if outc == "pax_dom":
                d.to_csv(OUT / f"stacked_{kind}.csv", index=False)
                tr, un = transfers(kind, d)
                tr.to_csv(OUT / f"transfers_{kind}.csv", index=False)
                un.to_csv(OUT / f"unit_effects_{kind}.csv", index=False)
                print(tr.round(3).to_string()); print(un.round(3).to_string())
                stt = stack_transfer(kind, d); stt.to_csv(OUT / f"stack_transfer_{kind}.csv", index=False)
                print(stt.round(3).to_string())
                event_study(d, kind).to_csv(OUT / f"event_study_{kind}.csv", index=False)
    S = pd.DataFrame(summ); S.to_csv(OUT / "pooled_main.csv", index=False)
    print(S.round(4).to_string())
