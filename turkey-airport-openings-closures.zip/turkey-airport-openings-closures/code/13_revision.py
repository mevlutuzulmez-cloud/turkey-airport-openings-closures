"""Revision analyses (response to the simulated review).

1. Imputation estimator (Borusyak-Jaravel-Spiess logic): a model of untreated airport-months
   (airport x stack and month x stack effects; outcome net of each airport's long-run seasonal
   profile) is fitted on controls and on exposed/focal airports' pre-event months, and used to
   impute counterfactual traffic in levels for every treated airport-month. The closed airport's
   counterfactual comes from the same model, so numerator and denominator are consistent.
   Variant 'trend': exposed and focal airports also get their own linear trend, fitted on
   pre-event months only and extrapolated.
2. Closure windows extended 12 months beyond reopening: tests reversal and catch-up.
3. Decomposition of the neighbours' gain into commercial flights and passengers per flight.
4. Inference: placebo *focal* airports (a random control airport is treated as the closed/opened
   airport and the control airports within 180 min of it as exposed) and a wild cluster
   restricted bootstrap (Webb weights) for the pooled stacked DiD coefficient.
5. Sample variants: contamination radius 300, earthquake-zone and 2015-16 conflict months
   removed, 240-300-min airports as controls.
"""
import sys, warnings
import numpy as np, pandas as pd, pyfixest as pf
from common import *
warnings.filterwarnings("ignore")
RNG = np.random.default_rng(20261115)
P, T = load_panel(), road_time()
QUAKE = (["HTY", "KCM", "GZT", "MLX", "ADF", "GNY", "DIY", "ADA", "COV", "EZS"], "2023-02-01", "2024-06-01")
CONFLICT = (["DIY", "MQM", "BAL", "SXZ", "NKT", "YKO", "VAN", "MSR", "BGG", "GNY", "AJI", "IGD", "KSY"], "2015-07-01", "2016-12-01")
OPEN_GROUPS = {}
for j, d in OPENINGS:
    OPEN_GROUPS.setdefault(pd.Timestamp(d), []).append(j)


# ---------- seasonal profiles from long history ----------
def seasonal_profiles(outcome):
    """Airport-specific month-of-year profile of log traffic, from a regression on year and
    month dummies using all months except COVID, the airport's own closures and months in which a
    closure or opening occurred within 180 min (event-free months)."""
    p = P[P[outcome] > 0].copy()
    p = p[~((p.date >= COVID[0]) & (p.date <= COVID[1]))]
    sh = shock_table()
    bad = np.zeros(len(p), bool)
    for s in sh.itertuples():
        near = (p.code.map(T[s.focal]) <= 180).values | (p.code == s.focal).values
        if s.kind == "closure":
            bad |= near & ((p.date >= s.start) & (p.date <= s.end)).values
        else:
            bad |= near & ((p.date >= s.start) & (p.date < s.start + pd.DateOffset(months=12))).values
    p = p[~bad]
    p["yr"] = p.date.dt.year; p["moy"] = p.date.dt.month; p["ly"] = np.log(p[outcome])
    out = {}
    for c, g in p.groupby("code"):
        if g.moy.nunique() < 12 or len(g) < 36: continue
        g = g.copy(); g["dev"] = g.ly - g.groupby("yr").ly.transform("mean")
        prof = g.groupby("moy").dev.median(); prof -= prof.mean()
        for m, v in prof.items(): out[(c, m)] = v
    return out
SEAS = {o: seasonal_profiles(o) for o in ["pax_dom", "com_atm_dom"]}


def stacks(kind, outcome="pax_dom", **kw):
    S = []
    if kind == "opening":
        for d, fs in OPEN_GROUPS.items():
            S.append(build_stack(fs, d, None, "opening", P, T, outcome=outcome, keep_focal=False, **kw))
    else:
        kw.setdefault("after", 12)
        for j, a, b in CLOSURES:
            S.append(build_stack([j], pd.Timestamp(a), pd.Timestamp(b), "closure", P, T, outcome=outcome, keep_focal=True, **kw))
    S = [s for s in S if s.treated.sum() > 0]
    out = []
    for s in S:
        s = s.copy()
        s["s"] = [SEAS[outcome].get((c, m), np.nan) for c, m in zip(s.code, s.moy)]
        s = s.dropna(subset=["s"])
        s["ya"] = s.y - s.s
        s["tt"] = s.rel / 12.0
        # treated airport-months (excluded from the untreated model)
        s["is_tr"] = (((s.treated == 1) | (s.focal == 1)) & ((s.post == 1) | (s.get("after", 0) == 1))).astype(int)
        out.append(s)
    return out


def impute(s, outcome="pax_dom", trend=False):
    """Impute counterfactual levels Y0 for treated rows of one stack."""
    s = add_fe_ids(s)
    U = s[(s.is_tr == 0) & s.ya.notna()].copy()
    tr_units = sorted(s[(s.treated == 1) | (s.focal == 1)].code.unique())
    rhs = "1"
    if trend:
        for c in tr_units:
            U[f"tr_{c}"] = (U.code == c) * U.tt; s[f"tr_{c}"] = (s.code == c) * s.tt
        rhs = " + ".join(f"tr_{c}" for c in tr_units)
    m = pf.feols(f"ya ~ {rhs} | fe_unit + fe_time", data=U)
    fe = m.fixef()
    fu = fe[fe.variable == "fe_unit"].set_index("level").coefficient
    ft = fe[fe.variable == "fe_time"].set_index("level").coefficient
    U["res"] = U.ya - (U.fe_unit.map(fu) + U.fe_time.map(ft) + (sum(m.coef()[f"tr_{c}"] * U[f"tr_{c}"] for c in tr_units) if trend else 0))
    smear = U.groupby("code").res.apply(lambda r: np.mean(np.exp(r)))
    R = s[s.is_tr == 1].copy()
    lin = R.fe_unit.map(fu) + R.fe_time.map(ft) + R.s
    if trend:
        lin = lin + sum(m.coef()[f"tr_{c}"] * R[f"tr_{c}"] for c in tr_units)
    R["Y0"] = np.exp(lin) * R.code.map(smear)
    R["Y1"] = R[outcome]
    return R.dropna(subset=["Y0"])


def summarise(kind, R, s, outcome="pax_dom"):
    st = s["stack"].iloc[0]; focals = st.split("-")[0].split("+")
    ex = R[R.treated == 1]
    if kind == "opening":
        months = sorted(ex.date.unique())
        den = P[P.code.isin(focals) & P.date.isin(months)][outcome].sum()
        moved = (ex.Y0 - ex.Y1).sum()
        return dict(stack=st, kind=kind, exposed=",".join(sorted(ex.code.unique())), months=len(months),
                    exposed_Y0=ex.Y0.sum(), moved=moved, focal=den, ratio=moved / den, rel_effect=moved / ex.Y0.sum())
    dur, aft = ex[ex.post == 1], ex[ex.after == 1]
    if dur.Y0.sum() == 0:
        return dict(stack=st, kind=kind, exposed="", months=0, exposed_Y0=0.0, moved=0.0, focal=0.0, ratio=np.nan, rel_effect=np.nan)
    f = R[R.focal == 1]; fd, fa = f[f.post == 1], f[f.after == 1]
    lost = (fd.Y0 - fd.Y1).sum(); gain = (dur.Y1 - dur.Y0).sum()
    return dict(stack=st, kind=kind, exposed=",".join(sorted(dur.code.unique())), months=dur.date.nunique(),
                exposed_Y0=dur.Y0.sum(), moved=gain, focal=lost, ratio=gain / lost if lost > 0 else np.nan,
                rel_effect=gain / dur.Y0.sum(),
                after_exposed_rel=(aft.Y1 - aft.Y0).sum() / aft.Y0.sum() if len(aft) else np.nan,
                after_focal_rel=(fa.Y1 - fa.Y0).sum() / fa.Y0.sum() if len(fa) else np.nan,
                after_focal_extra=(fa.Y1 - fa.Y0).sum() if len(fa) else np.nan,
                focal_pre_mean=s[(s.focal == 1) & (s.date < s[s.post == 1].date.min())][outcome].mean(),
                exposed_pre_mean=s[(s.treated == 1) & (s.date < s[s.post == 1].date.min())][outcome].mean())


def placebo_rel(s, kind, trend=False, B=150, outcome="pax_dom"):
    """Relative effects (sum(Y1-Y0)/sum(Y0)) at the airports within 180 min of a randomly drawn
    *control* airport treated as a fake focal airport (real exposed/focal airports dropped)."""
    c = s[(s.treated == 0) & (s.focal == 0)].copy()
    codes = c.code.unique()
    cand = [k for k in codes if ((T.loc[k, [x for x in codes if x != k]] <= 180).sum() >= 1)]
    rels = []
    for _ in range(B):
        k = RNG.choice(cand)
        nb = [x for x in codes if x != k and T.loc[k, x] <= 180]
        g = c.copy()
        g["treated"] = g.code.isin(nb).astype(int); g["focal"] = (g.code == k).astype(int) if kind == "closure" else 0
        if kind == "opening":
            g = g[g.code != k]
        g["is_tr"] = (((g.treated == 1) | (g.focal == 1)) & ((g.post == 1) | (g.get("after", 0) == 1))).astype(int)
        try:
            R = impute(g, outcome, trend)
        except Exception:
            continue
        ex = R[(R.treated == 1) & (R.post == 1)]
        if len(ex): rels.append((ex.Y1 - ex.Y0).sum() / ex.Y0.sum())
    return np.array(rels)


def wild_bootstrap(d, reps=499):
    """WCR bootstrap p-value (Webb 6-point weights, clusters = airports) for D in Eq. (1)."""
    d = add_fe_ids(d)
    m = pf.feols("y ~ D | fe_unit + fe_time + fe_season", data=d, vcov={"CRV1": "code"}, fixef_rm="none")
    t0 = m.tidy().loc["D", "t value"]
    d = d.reset_index(drop=True)
    r = pf.feols("y ~ 1 | fe_unit + fe_time + fe_season", data=d, fixef_rm="none")
    u = np.asarray(r.resid()); assert len(u) == len(d)
    fit = d.y.values - u
    cl = d.code.values; uc = np.unique(cl); idx = np.searchsorted(uc, cl)
    W = np.array([-np.sqrt(1.5), -1, -np.sqrt(.5), np.sqrt(.5), 1, np.sqrt(1.5)])
    ts = []
    for _ in range(reps):
        w = RNG.choice(W, size=len(uc))[idx]
        dd = d.copy(); dd["y"] = fit + w * u
        ts.append(pf.feols("y ~ D | fe_unit + fe_time + fe_season", data=dd, vcov={"CRV1": "code"}, fixef_rm="none").tidy().loc["D", "t value"])
    ts = np.array(ts)
    return t0, (np.abs(ts) >= abs(t0)).mean(), len(uc)


def run(label, kinds=("opening", "closure"), B=150, **kw):
    rows, units = [], []
    for kind in kinds:
        for trend in [False, True]:
            S = stacks(kind, **kw)
            res, null_moved = [], []
            for s in S:
                R = impute(s, trend=trend)
                r = summarise(kind, R, s); r.update(trend=trend, spec=label)
                pl = placebo_rel(s, kind, trend, B=B) if B else np.array([])
                if len(pl):
                    null = r["exposed_Y0"] * (pl - pl.mean())          # passengers moved under the null
                    r["ratio_lo"] = r["ratio"] - np.percentile(null, 97.5) / r["focal"]
                    r["ratio_hi"] = r["ratio"] - np.percentile(null, 2.5) / r["focal"]
                    r["p_placebo"] = (np.abs(pl - pl.mean()) >= abs(r["rel_effect"])).mean()
                    null_moved.append(RNG.choice(null, 4000))
                res.append(r)
                if not trend and label == "main":
                    ex = R[(R.treated == 1) & (R.post == 1)]
                    for c, g in ex.groupby("code"):
                        units.append(dict(stack=r["stack"], kind=kind, code=c, rt=s[s.code == c].rt.iloc[0],
                                          Y0=g.Y0.sum(), Y1=g.Y1.sum(), moved=(g.Y1 - g.Y0).sum() * (1 if kind == "closure" else -1),
                                          rel=(g.Y1 - g.Y0).sum() / g.Y0.sum(), focal_total=r["focal"],
                                          pre_mean=s[(s.code == c) & (s.post == 0) & (s.get("after", 0) == 0)].pax_dom.mean(),
                                          focal_pre_mean=r.get("focal_pre_mean", np.nan)))
            agg = dict(stack="ALL", kind=kind, trend=trend, spec=label, moved=sum(x["moved"] for x in res),
                       focal=sum(x["focal"] for x in res), exposed_Y0=sum(x["exposed_Y0"] for x in res))
            agg["ratio"] = agg["moved"] / agg["focal"]
            if null_moved:
                tot = np.sum(null_moved, axis=0)
                agg["ratio_lo"] = agg["ratio"] - np.percentile(tot, 97.5) / agg["focal"]
                agg["ratio_hi"] = agg["ratio"] - np.percentile(tot, 2.5) / agg["focal"]
            rows += res + [agg]
            print(label, kind, "trend" if trend else "level", {k: round(v, 3) for k, v in agg.items() if isinstance(v, float)}, flush=True)
    return pd.DataFrame(rows), pd.DataFrame(units)


if __name__ == "__main__":
    which = sys.argv[1] if len(sys.argv) > 1 else "all"
    if which in ("all", "main"):
        R, U = run("main", B=100, r_contam=180, drop_months=[QUAKE])
        R.to_csv(OUT / "rev_impute_main.csv", index=False); U.to_csv(OUT / "rev_units_main.csv", index=False)
        # flights decomposition (closures and openings, no trend)
        rows = []
        for kind in ["opening", "closure"]:
            for outc in ["pax_dom", "com_atm_dom"]:
                for s in stacks(kind, outcome=outc, r_contam=180, drop_months=[QUAKE], min_size=5000 if outc == "pax_dom" else 30):
                    if outc == "com_atm_dom":
                        s = s[s.code.isin(s.code.unique())]
                    R = impute(s, outcome=outc)
                    ex = R[(R.treated == 1) & (R.post == 1)]; f = R[(R.focal == 1) & (R.post == 1)]
                    rows.append(dict(kind=kind, outcome=outc, stack=s["stack"].iloc[0], exposed_rel=(ex.Y1 - ex.Y0).sum() / ex.Y0.sum(),
                                     exposed_diff=(ex.Y1 - ex.Y0).sum(), focal_diff=(f.Y1 - f.Y0).sum() if len(f) else np.nan))
        pd.DataFrame(rows).to_csv(OUT / "rev_flights_decomposition.csv", index=False)
        print(pd.DataFrame(rows).round(3).to_string())
    if which in ("all", "variants"):
        out = []
        for label, kw in [("contamination radius 300", dict(r_contam=300, drop_months=[QUAKE])),
                          ("2015-16 conflict months removed", dict(r_contam=180, drop_months=[QUAKE, CONFLICT])),
                          ("controls 240-300 min only", dict(r_contam=180, drop_months=[QUAKE], r_control=240, drop_buffer=False)),
                          ("earthquake months kept", dict(r_contam=180))]:
            kw2 = dict(kw)
            if label.startswith("controls 240"):
                # keep only exposed (<=180) and 240-300-min airports
                Rr = []
                for kind in ["opening", "closure"]:
                    for trend in [False]:
                        S = stacks(kind, **{k: v for k, v in kw2.items()})
                        res = []
                        for s in S:
                            s = s[(s.treated == 1) | (s.focal == 1) | ((s.rt > 240) & (s.rt <= 300))]
                            R_ = impute(s, trend=trend); res.append(summarise(kind, R_, s))
                        Rr.append(dict(spec=label, kind=kind, trend=trend, ratio=sum(x["moved"] for x in res) / sum(x["focal"] for x in res)))
                out += Rr; print(Rr, flush=True); continue
            R, _ = run(label, B=0, **kw2)
            out += R[R["stack"] == "ALL"][["spec", "kind", "trend", "ratio"]].to_dict("records")
        pd.DataFrame(out).to_csv(OUT / "rev_impute_variants.csv", index=False)
    if which in ("all", "wild"):
        rows = []
        for kind in ["opening", "closure"]:
            S = [s for s in stacks(kind, r_contam=180, drop_months=[QUAKE])]
            d = pd.concat(S); d = d[(d.focal == 0) & (d.get("after", 0) == 0) & d.y.notna()]
            t0, p, G = wild_bootstrap(d, reps=499)
            rows.append(dict(kind=kind, t=t0, p_wcr=p, clusters=G)); print(rows[-1], flush=True)
        pd.DataFrame(rows).to_csv(OUT / "rev_wild_bootstrap.csv", index=False)
