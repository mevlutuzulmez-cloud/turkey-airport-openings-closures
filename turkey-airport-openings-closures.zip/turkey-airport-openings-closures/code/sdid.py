"""sdid.py - Synthetic difference-in-differences (Arkhangelsky et al., 2021, AER), Algorithm 1,
with placebo (Algorithm 4) and jackknife (Algorithm 3) variance estimators.
Also returns the synthetic-control (SC) and unweighted DiD estimates for comparison.
Y is an (N x T) array, `tr` a boolean vector marking treated units, T0 the number of pre-treatment periods.
"""
import numpy as np
from scipy.optimize import minimize


def _simplex_ls(A, b, zeta2, n_rows):
    """min_x (1/n_rows)||A x - b||^2 + zeta2 ||x||^2  s.t. x >= 0, sum(x) = 1"""
    k = A.shape[1]
    AtA = A.T @ A / n_rows + zeta2 * np.eye(k)
    Atb = A.T @ b / n_rows
    f = lambda x: x @ AtA @ x - 2 * Atb @ x
    g = lambda x: 2 * (AtA @ x - Atb)
    x0 = np.full(k, 1.0 / k)
    res = minimize(f, x0, jac=g, method='SLSQP', bounds=[(0, 1)] * k,
                   constraints=[{'type': 'eq', 'fun': lambda x: x.sum() - 1, 'jac': lambda x: np.ones(k)}],
                   options={'maxiter': 2000, 'ftol': 1e-14})
    x = np.clip(res.x, 0, None)
    return x / x.sum()


def weights(Y, tr, T0):
    Yco, Ytr = Y[~tr], Y[tr]
    Ntr, Tpost = Ytr.shape[0], Y.shape[1] - T0
    sd = np.diff(Yco[:, :T0], axis=1).std(ddof=1)
    zeta = (Ntr * Tpost) ** 0.25 * sd
    # unit weights (intercept -> demean each unit's pre-period series)
    A = Yco[:, :T0].T
    b = Ytr[:, :T0].mean(0)
    om = _simplex_ls(A - A.mean(0), b - b.mean(), zeta ** 2, T0)
    # time weights (intercept -> demean each period across control units)
    A2 = Yco[:, :T0]
    b2 = Yco[:, T0:].mean(1)
    lam = _simplex_ls(A2 - A2.mean(0), b2 - b2.mean(), (1e-6 * sd) ** 2, Yco.shape[0])
    return om, lam


def _tau(Y, tr, T0, om, lam):
    gap = Y[tr].mean(0) - om @ Y[~tr]           # treated-minus-synthetic gap, by period
    base = lam @ gap[:T0]
    return gap[T0:].mean() - base, gap - base   # ATT, period-specific (centred) gaps


def sc_weights(Y, tr, T0):
    A = Y[~tr][:, :T0].T
    b = Y[tr][:, :T0].mean(0)
    return _simplex_ls(A, b, 0.0, T0)


def estimate(Y, tr, T0, B=1000, seed=20220224, placebo=True):
    Y = np.asarray(Y, float)
    tr = np.asarray(tr, bool)
    N, T = Y.shape
    Nco, Ntr = (~tr).sum(), tr.sum()
    om, lam = weights(Y, tr, T0)
    tau, gaps = _tau(Y, tr, T0, om, lam)
    out = dict(tau=tau, gaps=gaps, omega=om, lam=lam, N=N, Nco=int(Nco), Ntr=int(Ntr), T0=T0, Tpost=T - T0)
    # comparison estimators
    uni_o, uni_l = np.full(Nco, 1 / Nco), np.full(T0, 1 / T0)
    out['did'] = _tau(Y, tr, T0, uni_o, uni_l)[0]
    osc = sc_weights(Y, tr, T0)
    gsc = Y[tr].mean(0) - osc @ Y[~tr]
    out['sc'] = gsc[T0:].mean()
    out['pre_rmse_sdid'] = float(np.sqrt(np.mean((gaps[:T0] - gaps[:T0].mean()) ** 2)))
    out['pre_rmse_did'] = float(np.sqrt(np.mean(((Y[tr].mean(0) - Y[~tr].mean(0))[:T0]
                                                  - (Y[tr].mean(0) - Y[~tr].mean(0))[:T0].mean()) ** 2)))
    # jackknife (fixed weights), valid for Ntr > 1
    if Ntr > 1:
        co_idx, tr_idx = np.where(~tr)[0], np.where(tr)[0]
        th = []
        for i in range(N):
            keep = np.ones(N, bool); keep[i] = False
            o = om.copy()
            if not tr[i]:
                j = np.where(co_idx == i)[0][0]
                o = np.delete(o, j)
                if o.sum() <= 0:
                    continue
                o = o / o.sum()
            th.append(_tau(Y[keep], tr[keep], T0, o, lam)[0])
        th = np.array(th)
        out['se_jack'] = float(np.sqrt((len(th) - 1) / len(th) * ((th - th.mean()) ** 2).sum()))
    # placebo: reassign treatment among controls
    if placebo and Nco > Ntr + 2:
        rng = np.random.default_rng(seed)
        Yc = Y[~tr]
        pl = np.empty(B)
        pl_gaps = np.empty((B, T))
        for b_ in range(B):
            fake = np.zeros(Nco, bool)
            fake[rng.choice(Nco, Ntr, replace=False)] = True
            o, l = weights(Yc, fake, T0)
            pl[b_], pl_gaps[b_] = _tau(Yc, fake, T0, o, l)
        out['se_placebo'] = float(pl.std(ddof=1))
        out['p_placebo_rank'] = float((np.abs(pl) >= abs(tau)).mean())
        out['se_gaps_placebo'] = pl_gaps.std(axis=0, ddof=1)
        out['placebo_draws'] = pl
        out['placebo_gaps'] = pl_gaps
    return out
