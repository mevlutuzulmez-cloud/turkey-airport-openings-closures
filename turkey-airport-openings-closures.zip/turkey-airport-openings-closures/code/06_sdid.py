"""Synthetic difference-in-differences (Arkhangelsky et al., 2021) by stack, as a check on the
stacked regression: re-weights control airports and pre-periods so that pre-trends are matched.
Outcome: log domestic passengers net of each airport's pre-period month-of-year mean."""
import warnings
import numpy as np, pandas as pd
from common import *
import sdid
from importlib import import_module
warnings.filterwarnings("ignore")
M = import_module("05_main")
P, T = M.P, M.T
PRE = {"RZV": 40}   # RZV: lengthen the pre-window so that 24 non-COVID months remain


def wide(g):
    g = g.copy()
    pre = g[g.post == 0] if g.kind.iloc[0] == "opening" else g[g.date < g[g.post == 1].date.min()]
    seas = pre.groupby(["code", "moy"]).y.mean().rename("s")
    g = g.join(seas, on=["code", "moy"])
    g["ya"] = g.y - g.s
    W = g.pivot_table(index="code", columns="date", values="ya")
    # short gaps (dropped, contaminated months) are linearly interpolated within airport (max 8 months);
    # airports with longer gaps are dropped (robustness check only)
    W = W.T.interpolate(limit=8, limit_area="inside").bfill(limit=3).ffill(limit=3).T
    W = W.dropna(axis=0)
    return W


rows = []
for kind in ["opening", "closure"]:
    S = []
    if kind == "opening":
        for d, fs in M.opening_groups().items():
            S.append(build_stack(fs, d, None, "opening", P, T, pre=PRE.get(fs[0], 24)))
    else:
        for j, a, b in CLOSURES:
            S.append(build_stack([j], pd.Timestamp(a), pd.Timestamp(b), "closure", P, T))
    for g in S:
        st = g["stack"].iloc[0]
        tr_codes = M.usable_treated(g)
        if not tr_codes: continue
        g = g[(g.treated == 0) | g.code.isin(tr_codes)]
        W = wide(g)
        tr = W.index.isin(tr_codes)
        if tr.sum() == 0 or (~tr).sum() < tr.sum() + 4:
            print("skip", st, tr.sum()); continue
        start = g[g.post == 1].date.min()
        T0 = int((W.columns < start).sum())
        r = sdid.estimate(W.values, tr, T0, B=500)
        post = g[g.code.isin(W.index[tr]) & (g.post == 1)]
        y1 = post.pax_dom.sum()
        focals = st.split("-")[0].split("+")
        months = sorted(post.date.unique())
        if kind == "opening":
            base = P[P.code.isin(focals) & P.date.isin(months)].pax_dom.sum()
            mv = y1 * (np.exp(-r["tau"]) - 1); sims = y1 * (np.exp(-(r["tau"] + r["placebo_draws"] - r["placebo_draws"].mean())) - 1)
        else:
            cf = M.closed_counterfactual(focals[0], months, g)
            base = cf - P[(P.code == focals[0]) & P.date.isin(months)].pax_dom.sum()
            mv = -y1 * (np.exp(-r["tau"]) - 1); sims = -y1 * (np.exp(-(r["tau"] + r["placebo_draws"] - r["placebo_draws"].mean())) - 1)
        rows.append(dict(kind=kind, stack=st, treated=",".join(W.index[tr]), n_ctrl=int((~tr).sum()), T0=T0,
                         Tpost=r["Tpost"], sdid=r["tau"], se_placebo=r["se_placebo"], p_placebo=r["p_placebo_rank"],
                         did=r["did"], sc=r["sc"], pre_rmse_sdid=r["pre_rmse_sdid"], pre_rmse_did=r["pre_rmse_did"],
                         ratio=mv / base, ci_lo=np.percentile(sims / base, 2.5), ci_hi=np.percentile(sims / base, 97.5),
                         exposed_pax=y1, focal_pax=base, moved=mv))
        np.save(OUT / f"sdid_gaps_{st}.npy", np.vstack([r["gaps"], r["se_gaps_placebo"]]))
        print(pd.DataFrame(rows[-1:]).round(3).to_string(), flush=True)
R = pd.DataFrame(rows); R.to_csv(OUT / "sdid_by_stack.csv", index=False)
# pooled transfer ratios (sum of moved over sum of focal) by kind
for k, g in R.groupby("kind"):
    print(k, "pooled ratio", round(g.moved.sum() / g.focal_pax.sum(), 3))
