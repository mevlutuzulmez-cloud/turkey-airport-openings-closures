"""Airport coordinates (OurAirports, public domain) and road distance/time matrix (OSRM public server)."""
import sys, json, requests, numpy as np, pandas as pd
from pathlib import Path
codes = sorted(pd.read_csv("data/panel_airport_month.csv").code.unique())
oa = pd.read_csv("data/raw/ourairports_airports.csv", usecols=["iata_code", "ident", "name", "latitude_deg", "longitude_deg", "municipality", "iso_country"])
look = {c: c for c in codes}; look["ISL"] = "ISL"  # Istanbul Ataturk IATA ISL
a = oa[oa.iata_code.isin(codes) & (oa.iso_country == "TR")].drop_duplicates("iata_code").set_index("iata_code")
miss = [c for c in codes if c not in a.index]; print("missing", miss)
a = a.loc[codes].reset_index().rename(columns={"index": "code", "iata_code": "code", "latitude_deg": "lat", "longitude_deg": "lon"})
a.to_csv("data/airports_coords.csv", index=False)
coords = ";".join(f"{r.lon:.5f},{r.lat:.5f}" for r in a.itertuples())
r = requests.get(f"https://router.project-osrm.org/table/v1/driving/{coords}?annotations=duration,distance", timeout=120, headers={"User-Agent": "research-script"}).json()
assert r["code"] == "Ok", r
dur = pd.DataFrame(np.array(r["durations"]) / 60, index=codes, columns=codes)
dist = pd.DataFrame(np.array(r["distances"]) / 1000, index=codes, columns=codes)
# great-circle for reference
la, lo = np.radians(a.lat.values), np.radians(a.lon.values)
gc = 6371 * 2 * np.arcsin(np.sqrt(np.sin((la[:, None] - la) / 2) ** 2 + np.cos(la[:, None]) * np.cos(la) * np.sin((lo[:, None] - lo) / 2) ** 2))
pd.DataFrame(gc, index=codes, columns=codes).to_csv("data/dist_greatcircle_km.csv")
dur.to_csv("data/road_time_min.csv"); dist.to_csv("data/road_dist_km.csv")
print(dur.round(0).loc[["RZV", "OGU", "IGD", "NKT", "BGG", "KFS", "YKO", "KZR"]].apply(lambda s: s.nsmallest(5).index.tolist() + s.nsmallest(5).round(0).astype(int).tolist(), axis=1).to_string())
