"""Download the all-in-one monthly (cumulative YTD) DHMI spreadsheet for every year-month."""
import json, sys, time, requests
from pathlib import Path
from urllib.parse import quote, unquote
idx = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
out = Path(sys.argv[2]); out.mkdir(parents=True, exist_ok=True)
S = requests.Session(); S.headers["User-Agent"] = "Mozilla/5.0"
for y, rows in idx.items():
    for m, r in enumerate(rows, 1):
        xl = [l for l in r["links"] if l.lower().endswith((".xls", ".xlsx"))]
        if not xl:
            print("NO EXCEL", y, m, r["links"]); continue
        # prefer the combined workbook (TÜMÜ) if several
        xl.sort(key=lambda l: ("T%C3%9CM%C3%9C" not in quote(unquote(l)) and "TÜMÜ" not in unquote(l), l))
        url = xl[0]; ext = url.rsplit(".", 1)[1].lower()
        f = out / f"{y}-{m:02d}.{ext}"
        if f.exists() and f.stat().st_size > 1000: continue
        u = "https://www.dhmi.gov.tr" + quote(unquote(url.split("dhmi.gov.tr", 1)[1]))
        b = S.get(u, timeout=60).content
        f.write_bytes(b); print(y, m, len(xl), unquote(url).rsplit("/", 1)[1], len(b), flush=True)
        time.sleep(0.5)
