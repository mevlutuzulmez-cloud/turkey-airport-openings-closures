"""Additional figures for the revised manuscript (descriptive and revision results)."""
import sys, json, warnings
import numpy as np, pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib.patches import FancyArrowPatch
from common import *
warnings.filterwarnings("ignore")
P, T = load_panel(), road_time()
BLUE, ORANGE, AQUA, GREY, INK, MUTED, LIGHT = "#2a78d6", "#eb6834", "#1baf7a", "#b9b8b0", "#1f1f1d", "#6b6a64", "#f3f2ee"
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 8.5, "axes.edgecolor": MUTED, "axes.labelcolor": INK,
                     "xtick.color": MUTED, "ytick.color": MUTED, "axes.spines.top": False, "axes.spines.right": False,
                     "axes.grid": True, "grid.color": "#e6e5e0", "grid.linewidth": 0.6, "legend.frameon": False})
NAMES = {"IGD": "Iğdır", "KZR": "Zafer", "NKT": "Şırnak", "BGG": "Bingöl", "KFS": "Kastamonu", "OGU": "Ordu-Giresun",
         "YKO": "Hakkari", "RZV": "Rize-Artvin", "MQM": "Mardin", "DIY": "Diyarbakır", "BAL": "Batman", "MZH": "Amasya-Merzifon",
         "NAV": "Kapadokya", "SZF": "Samsun", "VAN": "Van", "TZX": "Trabzon", "KSY": "Kars", "AJI": "Ağrı", "ERZ": "Erzurum",
         "EZS": "Elazığ", "MSR": "Muş", "NOP": "Sinop", "GNY": "Şanlıurfa", "ADF": "Adıyaman", "ASR": "Kayseri", "SXZ": "Siirt",
         "USQ": "Uşak", "AOE": "Eskişehir", "TJK": "Tokat"}
nm = lambda c: NAMES.get(c, c)
def save(fig, name): fig.savefig(FIG / f"{name}.png", dpi=600, bbox_inches="tight"); plt.close(fig)
W = P.pivot_table(index="date", columns="code", values="pax_dom")
WC = W.copy()                                   # closure months and COVID set missing
for _j, _a, _b in CLOSURES + CLOSURES_SMALL:
    if _j in WC: WC.loc[_a:_b, _j] = np.nan
WC.loc[COVID[0]:COVID[1]] = np.nan


def end_labels(ax, items, min_gap):
    """items: list of (y, text, color); place labels at right edge, nudged apart vertically."""
    items = sorted([i for i in items if np.isfinite(i[0])], key=lambda t: t[0])
    ys = []
    for y, _, _ in items:
        y2 = y if not ys or y - ys[-1] >= min_gap else ys[-1] + min_gap
        ys.append(y2)
    x = ax.get_xlim()[1]
    for (y, t, c), y2 in zip(items, ys):
        ax.annotate(t, (x, y2), xytext=(3, 0), textcoords="offset points", fontsize=5.8, color=c, va="center", annotation_clip=False)


def fig_network():
    """(a) airports with scheduled domestic traffic; (b) domestic passengers, new airports highlighted."""
    p = P.copy(); p["yr"] = p.date.dt.year
    yr = p[p.yr <= 2025]
    n = yr.groupby(["yr", "code"]).pax_dom.sum().unstack()
    active = (n > 10000).sum(axis=1)
    new = [j for j, _ in OPENINGS]
    tot = n.sum(axis=1) / 1e6; nw = n[new].sum(axis=1) / 1e6
    fig, axs = plt.subplots(1, 2, figsize=(7.4, 2.7), gridspec_kw=dict(wspace=0.3))
    axs[0].step(active.index, active.values, where="mid", color=INK, lw=1.6)
    for j, d in OPENINGS:
        y = pd.Timestamp(d).year
        dy = {"IGD": 10, "KZR": 20, "NKT": 10, "BGG": 20, "KFS": 30, "OGU": 10, "YKO": 20, "RZV": 10}[j]
        axs[0].annotate(nm(j), (y, active.loc[y]), xytext=(0, dy), textcoords="offset points",
                        fontsize=6.3, ha="center", color=BLUE, arrowprops=dict(arrowstyle="-", color=BLUE, lw=0.5))
    axs[0].set_ylabel("Airports with > 10,000 domestic pax/year"); axs[0].set_title("(a) Airports in service", loc="left", fontsize=8)
    axs[0].set_ylim(active.min() - 3, active.max() + 9)
    axs[1].fill_between(tot.index, 0, tot.values - nw.values, color=GREY, step=None, label="Other airports")
    axs[1].fill_between(tot.index, tot.values - nw.values, tot.values, color=BLUE, label="Eight new airports (2012–2022)")
    axs[1].set_ylabel("Domestic passengers (millions)"); axs[1].set_title("(b) Domestic passengers", loc="left", fontsize=8)
    axs[1].legend(loc="lower right", fontsize=7)
    for ax in axs: ax.set_xticks(range(2010, 2026, 3))
    sh = (nw / tot * 100)
    axs[1].annotate(f"{sh.loc[2025]:.1f}% in 2025", (2025, tot.loc[2025]), xytext=(-60, 10), textcoords="offset points", fontsize=7, color=BLUE)
    save(fig, "figA_network_growth")


def fig_closure_anatomy():
    """Small multiples: monthly domestic passengers of each closed airport and its neighbours (<= 180 min)."""
    fig, axs = plt.subplots(2, 4, figsize=(8.2, 4.4), gridspec_kw=dict(hspace=0.55, wspace=0.55))
    axs = axs.ravel()
    for ax, (j, a, b) in zip(axs, CLOSURES):
        a_, b_ = pd.Timestamp(a), pd.Timestamp(b)
        win = W.loc[a_ - pd.DateOffset(months=12): b_ + pd.DateOffset(months=12)] / 1e3
        nbs = [c for c in T[j].sort_values().index if c != j and T.loc[j, c] <= 180 and c in W and c not in HUBS
               and W.loc[a_ - pd.DateOffset(months=12): a_, c].mean() > 5000][:3]
        ax.axvspan(a_, b_ + pd.DateOffset(days=27), color=LIGHT, zorder=0)
        ax.plot(win.index, win[j], color=MUTED, lw=1.5)
        for k, c in enumerate(nbs):
            ax.plot(win.index, win[c], color=ORANGE, lw=1.2, ls=["-", "--", ":"][k])
        ax.set_xlim(win.index[0], win.index[-1])
        rng = np.nanmax(win[[j] + nbs].values)
        end_labels(ax, [(win[c].dropna().iloc[-1], nm(c), INK) for c in nbs], rng * 0.09)
        ax.set_title(f"{nm(j)}, {a_:%b %Y}–{b_:%b %Y}" if a_.year == b_.year else f"{nm(j)}, {a_:%b %Y}–{b_:%b %Y}", fontsize=6.4, loc="left")
        ax.xaxis.set_major_locator(mdates.MonthLocator(bymonth=[1])); ax.xaxis.set_major_formatter(mdates.DateFormatter("%Y"))
        ax.tick_params(labelsize=6)
    axs[0].set_ylabel("Domestic pax (000s/month)")
    axs[4].set_ylabel("Domestic pax (000s/month)")
    ax = axs[7]; ax.axis("off")
    ax.plot([], [], color=MUTED, lw=1.5, label="Closed airport"); ax.plot([], [], color=ORANGE, lw=1.2, label="Neighbours ≤ 180 min")
    ax.fill_between([], [], color=LIGHT, label="Closure"); ax.legend(loc="center", fontsize=7)
    save(fig, "figB_closure_anatomy")


def fig_opening_anatomy():
    """New airports' traffic ramp-up and their nearest incumbents, indexed to the opening month."""
    pairs = [("RZV", ["TZX"]), ("OGU", ["SZF", "TZX"]), ("IGD", ["KSY", "AJI"]), ("BGG", ["DIY", "MSR", "EZS"]),
             ("NKT", ["MQM", "BAL"]), ("YKO", ["VAN"])]
    fig, axs = plt.subplots(2, 3, figsize=(8.0, 4.2), gridspec_kw=dict(hspace=0.5, wspace=0.55))
    for ax, (j, inc) in zip(axs.ravel(), pairs):
        d0 = pd.Timestamp(dict(OPENINGS)[j])
        win = WC.loc[d0 - pd.DateOffset(months=24): d0 + pd.DateOffset(months=36)].copy()
        rel = [(x.year - d0.year) * 12 + x.month - d0.month for x in win.index]
        r12 = lambda s: s.rolling(12, min_periods=8).mean() * 12 / 1e3   # annualised 12-month rolling mean
        labs = []
        for k, c in enumerate(inc):
            ax.plot(rel, r12(win[c]), color=MUTED, lw=1.3, ls=["-", "--", ":"][k]); labs.append((r12(win[c]).dropna().iloc[-1], nm(c), INK))
        nwv = win[j].where(np.array(rel) >= 0, 0).fillna(0) if j != "RZV" else win[j].where(np.array(rel) >= 0, 0)
        ax.plot(rel, r12(nwv), color=BLUE, lw=1.8); labs.append((r12(nwv).dropna().iloc[-1], nm(j) + " (new)", BLUE))
        ax.axvline(0, color=MUTED, lw=0.8, ls=":")
        ax.set_xlim(-24, 36)
        top = max(l[0] for l in labs); end_labels(ax, labs, top * 0.08)
        ax.set_title(f"{nm(j)} opened {d0:%b %Y}", fontsize=7, loc="left"); ax.tick_params(labelsize=6)
    for ax in axs[:, 0]: ax.set_ylabel("Domestic pax per year (000s)", fontsize=6.5)
    for ax in axs[1]: ax.set_xlabel("Months since opening", fontsize=7)
    save(fig, "figC_opening_anatomy")


# ---------------- results figures (revision) ----------------
def _turkey(ax):
    geo = json.load(open(DATA / "raw" / "ne_50m_admin0.geojson", encoding="utf-8"))
    tur = [f for f in geo["features"] if f["properties"]["ADMIN"] == "Turkey"][0]["geometry"]
    for poly in (tur["coordinates"] if tur["type"] == "MultiPolygon" else [tur["coordinates"]]):
        xy = np.array(poly[0]); ax.fill(xy[:, 0], xy[:, 1], color=LIGHT, ec=GREY, lw=0.5, zorder=0)
    ax.set_aspect(1.25); ax.grid(False); ax.set_xticks([]); ax.set_yticks([]); [s.set_visible(False) for s in ax.spines.values()]


def fig_flow_map():
    """Passengers moved: (a) closures, closed airport -> neighbours (gains); (b) openings,
    incumbent -> new airport (losses), from the imputation estimator."""
    co = pd.read_csv(DATA / "airports_coords.csv").set_index("code")
    U = pd.read_csv(OUT / "rev_units_main.csv")
    fig, axs = plt.subplots(1, 2, figsize=(11.5, 3.6), gridspec_kw=dict(wspace=0.04))
    for ax, kind, col, title in [(axs[0], "closure", ORANGE, "(a) Closures: passengers gained by neighbours"),
                                  (axs[1], "opening", BLUE, "(b) Openings: passengers lost by incumbents (24 months)")]:
        _turkey(ax); ax.set_xlim(32.5, 45); ax.set_ylim(36.7, 42.35)
        ax.scatter(co.lon, co.lat, s=5, c=GREY, zorder=1)
        u = U[U.kind == kind]
        mx = U.moved.abs().max()
        for r in u.itertuples():
            focals = r.stack.split("-")[0].split("+")
            src = focals[0] if len(focals) == 1 else min(focals, key=lambda f: T.loc[f, r.code])
            a, b = (src, r.code) if kind == "closure" else (r.code, src)
            v = r.moved
            if v <= 0: continue
            lw = 0.6 + 7 * v / mx
            ax.add_patch(FancyArrowPatch((co.loc[a].lon, co.loc[a].lat), (co.loc[b].lon, co.loc[b].lat), connectionstyle="arc3,rad=0.25",
                                         arrowstyle="-|>", mutation_scale=6 + 6 * v / mx, lw=lw, color=col, alpha=0.85, zorder=3))
            mxp = ((co.loc[a].lon + co.loc[b].lon) / 2, (co.loc[a].lat + co.loc[b].lat) / 2)
            if v > 0.08 * mx:
                ax.annotate(f"{v/1e3:,.0f}k", mxp, fontsize=6, color=INK, ha="center", zorder=5,
                            bbox=dict(boxstyle="round,pad=0.15", fc="white", ec="none", alpha=0.8))
        foc = sorted({f for s in u["stack"] for f in s.split("-")[0].split("+")})
        ax.scatter(co.loc[foc].lon, co.loc[foc].lat, s=30, marker="s" if kind == "closure" else "^", c=col, ec="white", lw=0.6, zorder=4)
        OFF = {"KSY": (4, 4), "ASR": (4, -9), "NAV": (-38, 5), "DIY": (-46, 5), "BAL": (4, 5), "MQM": (4, -9), "TZX": (-14, -12),
               "RZV": (4, 4), "OGU": (-30, -12), "SZF": (-14, 6), "MZH": (-30, -11), "EZS": (-12, -11), "GNY": (-20, -11),
               "ADF": (-40, 2), "NOP": (4, 2), "MSR": (4, 3), "VAN": (5, -2), "YKO": (4, -8), "AJI": (4, 3), "IGD": (4, 3),
               "ERZ": (4, 3), "BGG": (4, 4), "NKT": (4, -9), "KFS": (4, 3)}
        for c in set(foc) | set(u.code):
            ax.annotate(nm(c), (co.loc[c].lon, co.loc[c].lat), xytext=OFF.get(c, (3, 3)), textcoords="offset points", fontsize=6, color=INK, zorder=6)
        ax.set_title(title, fontsize=8, loc="left")
    save(fig, "figD_flow_map")


def fig_capacity():
    """Share of the closed airport's lost flights relocated to neighbours vs share of lost passengers recaptured."""
    d = pd.read_csv(OUT / "rev_flights_decomposition.csv")
    c = d[d.kind == "closure"].pivot_table(index="stack", columns="outcome", values=["exposed_diff", "focal_diff"])
    c.columns = [f"{a}_{b}" for a, b in c.columns]
    c["flights"] = c.exposed_diff_com_atm_dom / -c.focal_diff_com_atm_dom
    c["pax"] = c.exposed_diff_pax_dom / -c.focal_diff_pax_dom
    m = pd.read_csv(OUT / "rev_impute_main.csv"); m = m[(m.kind == "closure") & (m.trend == False) & (m["stack"] != "ALL")].set_index("stack")
    c["size"] = m.focal_pre_mean / m.exposed_pre_mean
    fig, ax = plt.subplots(figsize=(4.4, 3.6))
    lim = (-0.45, 1.1)
    ax.plot(lim, lim, color=MUTED, lw=0.8, ls=":"); ax.axhline(0, color=GREY, lw=0.6); ax.axvline(0, color=GREY, lw=0.6)
    for st, r in c.iterrows():
        big = r["size"] > 1
        ax.scatter(r.flights, r.pax, s=30 + 25 * min(r["size"], 6), color=ORANGE if big else "white", ec=ORANGE, lw=1.2, zorder=3)
        dy = {"VAN": 8, "SZF": -12}.get(st.split("-")[0], -3)
        ax.annotate(nm(st.split("-")[0]) + f" {st.split('-')[1][:4]}", (r.flights, r.pax), xytext=(8, dy), textcoords="offset points", fontsize=6.5)
    ax.set_xlim(*lim); ax.set_ylim(*lim)
    ax.set_xlabel("Share of the closed airport's lost flights operated at neighbours")
    ax.set_ylabel("Share of its lost passengers recaptured by neighbours")
    ax.scatter([], [], s=60, color=ORANGE, ec=ORANGE, label="Closed airport larger than neighbours")
    ax.scatter([], [], s=60, color="white", ec=ORANGE, label="Closed airport smaller than neighbours")
    ax.legend(loc="upper left", fontsize=6.5)
    c.to_csv(OUT / "rev_capacity_vs_pax.csv")
    save(fig, "figE_capacity_vs_passengers")


def fig_persistence():
    """Traffic relative to counterfactual during the closure and in the 12 months after reopening."""
    m = pd.read_csv(OUT / "rev_impute_main.csv")
    m = m[(m.kind == "closure") & (m.trend == False) & (m["stack"] != "ALL")].copy()
    m["lab"] = m["stack"].map(lambda s: f"{nm(s.split('-')[0])} {s.split('-')[1][:4]}")
    m = m.sort_values("rel_effect", ascending=False)
    fig, axs = plt.subplots(1, 2, figsize=(7.2, 2.8), gridspec_kw=dict(wspace=0.55))
    y = np.arange(len(m))[::-1]
    axs[0].barh(y + 0.18, m.rel_effect.clip(upper=1.2), height=0.34, color=ORANGE, label="During closure")
    axs[0].barh(y - 0.18, m.after_exposed_rel, height=0.34, color="#f5b393", label="12 months after reopening")
    axs[0].set_yticks(y); axs[0].set_yticklabels(m.lab, fontsize=7); axs[0].axvline(0, color=MUTED, lw=0.8)
    axs[0].set_title("(a) Neighbours ≤ 180 min: traffic vs counterfactual", fontsize=7.5, loc="left"); axs[0].legend(fontsize=6.5, loc="lower right")
    axs[0].set_xlabel("Relative difference")
    axs[1].barh(y, m.after_focal_rel, height=0.5, color=MUTED)
    axs[1].set_yticks(y); axs[1].set_yticklabels(m.lab, fontsize=7); axs[1].axvline(0, color=MUTED, lw=0.8)
    axs[1].set_title("(b) Reopened airport, 12 months after", fontsize=7.5, loc="left"); axs[1].set_xlabel("Relative difference")
    for ax in axs: ax.grid(axis="y", visible=False)
    save(fig, "figF_persistence")


def summary_table():
    """Collect every estimate of the diversion share (openings) and recapture rate (closures)."""
    imp = pd.read_csv(OUT / "table3c_implied_ratios.csv")
    rev = pd.read_csv(OUT / "rev_impute_main.csv"); rev = rev[rev["stack"] == "ALL"]
    var = pd.read_csv(OUT / "rev_impute_variants.csv")
    sd = pd.read_csv(OUT / "sdid_by_stack.csv")
    unit = pd.read_csv(OUT / "rev_impute_main.csv"); unit = unit[(unit["stack"] != "ALL") & (unit.trend == False) & (unit.kind == "closure")]
    rows = []
    g = lambda k, t: rev[(rev.kind == k) & (rev.trend == t)].iloc[0]
    for k in ["opening", "closure"]:
        o = 0 if k == "opening" else 2
        rows += [dict(kind=k, est="Stacked DiD (log), no trend", r=imp.diversion[o], lo=imp.lo[o], hi=imp.hi[o]),
                 dict(kind=k, est="Stacked DiD (log), exposed-group trend", r=imp.diversion[o + 1], lo=imp.lo[o + 1], hi=imp.hi[o + 1]),
                 dict(kind=k, est="Imputation (levels), no trend", r=g(k, False).ratio, lo=g(k, False).ratio_lo, hi=g(k, False).ratio_hi),
                 dict(kind=k, est="Imputation (levels), pre-period trends", r=g(k, True).ratio, lo=g(k, True).ratio_lo, hi=g(k, True).ratio_hi),
                 dict(kind=k, est="Synthetic DiD", r=sd[sd.kind == k].moved.sum() / sd[sd.kind == k].focal_pax.sum(), lo=np.nan, hi=np.nan)]
        for lab in ["controls 240-300 min only", "contamination radius 300", "2015-16 conflict months removed"]:
            v = var[(var.spec == lab) & (var.kind == k) & (var.trend == False)]
            if len(v): rows.append(dict(kind=k, est=f"Imputation: {lab}", r=v.ratio.iloc[0], lo=np.nan, hi=np.nan))
    big = unit[unit["stack"].str[:3].isin(["DIY", "SZF", "VAN"])]; small = unit[~unit["stack"].str[:3].isin(["DIY", "SZF", "VAN"])]
    rows += [dict(kind="closure", est="Imputation: large airport closed (3 events)", r=big.moved.sum() / big.focal.sum(), lo=np.nan, hi=np.nan),
             dict(kind="closure", est="Imputation: small airport closed (4 events)", r=small.moved.sum() / small.focal.sum(), lo=np.nan, hi=np.nan)]
    t = pd.DataFrame(rows); t.to_csv(OUT / "rev_summary_ratios.csv", index=False)
    return t


def fig_summary():
    t = summary_table()
    fig, axs = plt.subplots(1, 2, figsize=(7.8, 3.9), sharey=False, gridspec_kw=dict(wspace=0.08, width_ratios=[1, 1]))
    for ax, k, col, mk, title in [(axs[0], "opening", BLUE, "o", "(a) Diversion share of openings"),
                                   (axs[1], "closure", ORANGE, "s", "(b) Recapture rate of closures")]:
        d = t[t.kind == k].reset_index(drop=True)
        y = np.arange(len(d))[::-1]
        ax.axvspan(0.25, 0.5, color=ORANGE, alpha=0.10, zorder=0)
        ax.axvline(0, color=MUTED, lw=0.8); ax.axvline(1, color=MUTED, lw=0.8, ls=":")
        for yi, r in zip(y, d.itertuples()):
            if np.isfinite(r.lo):
                lo, hi = max(r.lo, -1.0), min(r.hi, 1.6)
                ax.plot([lo, hi], [yi, yi], color=col, lw=1.3)
                if r.hi > 1.6: ax.annotate("", (1.66, yi), (1.5, yi), arrowprops=dict(arrowstyle="-|>", color=col, lw=1))
                if r.lo < -1.0: ax.annotate("", (-1.06, yi), (-0.9, yi), arrowprops=dict(arrowstyle="-|>", color=col, lw=1))
            ax.plot(r.r, yi, mk, color=col if np.isfinite(r.lo) else "white", mec=col, ms=5.5, zorder=3)
            ax.annotate(f"{r.r:.2f}", (r.r, yi), xytext=(0, 5), textcoords="offset points", fontsize=6, ha="center", color=INK)
        ax.set_yticks(y); ax.set_yticklabels(d.est, fontsize=6.6); ax.set_xlim(-1.1, 1.7); ax.grid(axis="y", visible=False)
        ax.set_title(title, fontsize=8, loc="left"); ax.set_xlabel("Ratio")
        if k == "closure": ax.yaxis.tick_right()
    save(fig, "figG_summary_ratios")


if __name__ == "__main__":
    F = {"network": fig_network, "closure": fig_closure_anatomy, "opening": fig_opening_anatomy, "flow": fig_flow_map,
         "capacity": fig_capacity, "persist": fig_persistence, "summary": fig_summary}
    for f in (sys.argv[1:] or list(F)):
        F[f]()
    print("ok")
