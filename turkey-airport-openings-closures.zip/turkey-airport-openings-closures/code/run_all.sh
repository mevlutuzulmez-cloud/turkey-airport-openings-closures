#!/usr/bin/env bash
# Full replication. Run from the code/ directory.
# Steps 0-4 rebuild the panel and distance matrices from the original sources (internet required).
# Skip them to start from the processed files shipped in data/.
set -e
export PYTHONIOENCODING=utf-8
if [ "$1" == "--from-source" ]; then
  python 00_list_dhmi.py ../data/raw/dhmi_index.json
  python 01_download_dhmi.py ../data/raw/dhmi_index.json ../data/raw/dhmi
  python 02_parse_raw.py ../data/raw/dhmi ../data/interim_ytd_long.csv
  python 03_build_panel.py ../data/interim_ytd_long.csv ../data/panel_airport_month.csv
  python 00b_download_aux.py
  python 04_distances.py
fi
[ -f ../data/raw/ne_50m_admin0.geojson ] || python 00b_download_aux.py
python 05_main.py            > ../output/log_main.txt
python 06_sdid.py            > ../output/log_sdid.txt
python 07_robustness.py      > ../output/log_robust.txt
python 08_placebo_checks.py  > ../output/log_placebo.txt
python 09_trend_break.py     > ../output/log_trend.txt
python 10_tables_figures.py  > ../output/log_tables.txt
python 13_revision.py all    > ../output/log_revision.txt
python 14_figures_v2.py      > ../output/log_figures.txt
echo "done"
