"""List DHMI monthly statistics attachments for every year (ASP.NET postback)."""
import re, html, json, sys, time
import requests
from pathlib import Path
URL = "https://www.dhmi.gov.tr/Sayfalar/Istatistikler.aspx"
OUT = Path(sys.argv[1])
S = requests.Session(); S.headers["User-Agent"] = "Mozilla/5.0"
def fields(page):
    d = {}
    for m in re.finditer(r'<input[^>]+type="hidden"[^>]*>', page):
        n = re.search(r'name="([^"]+)"', m.group(0)); v = re.search(r'value="([^"]*)"', m.group(0))
        if n: d[n.group(1)] = html.unescape(v.group(1)) if v else ""
    return d
def parse(page):
    # rows: month label followed by attachment links
    rows = []
    body = page[page.find('<table class="table table-hover'):]
    body = body[:body.find('</table>')]
    for tr in re.findall(r'<tr.*?</tr>', body, flags=re.S):
        txt = re.sub(r'\s+', ' ', html.unescape(re.sub('<[^>]+>', ' ', tr))).strip()
        links = [html.unescape(h) for h in re.findall(r'href="([^"]+)"', tr)]
        if links: rows.append({"label": txt, "links": links})
    return rows
p = S.get(URL, timeout=60).text
sel = re.search(r'name="([^"]+ddlyil)"', p).group(1)
res = {}
for y in range(2008, 2027):
    d = fields(p); d["__EVENTTARGET"] = sel; d["__EVENTARGUMENT"] = ""; d[sel] = str(y)
    p = S.post(URL, data=d, timeout=60).text
    res[y] = parse(p)
    print(y, len(res[y]), [r["label"][:20] for r in res[y]][:14], flush=True)
    time.sleep(1)
OUT.write_text(json.dumps(res, ensure_ascii=False, indent=1), encoding="utf-8")
