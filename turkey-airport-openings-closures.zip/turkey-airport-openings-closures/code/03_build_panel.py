"""Harmonise airport names, convert YTD to monthly values (using revised prior-year figures
from the following year's workbook when available) and write the airport-month panel."""
import sys, re
import numpy as np, pandas as pd
from pathlib import Path
src, out = Path(sys.argv[1]), Path(sys.argv[2])
TR = str.maketrans("İÜÇÖŞĞıüçöşğ", "IUCOSGiucosg")
RULES = [  # (regex on ascii-folded upper-case name, code)
 (r"MENDERES", "ADB"), (r"MERZIFON", "MZH"), (r"^ADANA", "ADA"), (r"ADIYAMAN", "ADF"),
 (r"CORLU", "TEQ"), (r"GAZIPASA", "GZP"), (r"^ANTALYA$", "AYT"), (r"ATATURK$|^ATATURK|ISTANBUL ATATURK", "ISL"),
 (r"ESENBOGA", "ESB"), (r"CILDIR", "CII"), (r"AGRI", "AJI"),
 (r"KORFEZ|KOCA SEYIT", "EDO"), (r"^BALIKESIR$|BALIKESIR MERKEZ", "BZI"), (r"BATMAN", "BAL"),
 (r"YENISEHIR", "YEI"), (r"BINGOL", "BGG"), (r"DALAMAN", "DLM"), (r"CARDAK", "DNZ"),
 (r"DIYARBAKIR", "DIY"), (r"ELAZIG", "EZS"), (r"ERZURUM", "ERZ"), (r"ERZINCAN", "ERC"),
 (r"ESKISEHIR", "AOE"), (r"GAZIANTEP", "GZT"), (r"GOKCEADA", "GKD"), (r"HATAY", "HTY"),
 (r"HAKKARI", "YKO"), (r"DEMIREL", "ISE"), (r"IGDIR", "IGD"), (r"MARAS", "KCM"),
 (r"^KARS", "KSY"), (r"KAYSERI", "ASR"), (r"^KONYA", "KYA"), (r"KAPADOKYA|NEVSEHIR", "NAV"),
 (r"KASTAMONU", "KFS"), (r"KOCAELI", "KCO"), (r"MALATYA", "MLX"), (r"MARDIN", "MQM"),
 (r"^MUS", "MSR"), (r"BODRUM", "BJV"), (r"ORDU", "OGU"), (r"RIZE", "RZV"),
 (r"CARSAMBA", "SZF"), (r"SIIRT", "SXZ"), (r"SINOP", "NOP"), (r"SIVAS", "VAS"),
 (r"TOKAT", "TJK"), (r"TRABZON", "TZX"), (r"USAK", "USQ"), (r"^VAN", "VAN"), (r"ZAFER", "KZR"),
 (r"ZONGULDAK", "ONQ"), (r"^CANAKKALE$", "CKZ"), (r"CUKUROVA", "COV"), (r"SABIHA", "SAW"),
 (r"^ISTANBUL ?\(\*\)$|^ISTANBUL$", "IST"), (r"URFA", "GNY"), (r"SIRNAK", "NKT")]
def code(n):
    a = n.upper().translate(TR).replace("İ", "I")
    a = re.sub(r"\s+", " ", a).strip()
    if any(k in a for k in ("TOPLAM", "GENEL", "DIREK", "OVERFLIGHT", "TR.Y")): return None
    for rx, c in RULES:
        if re.search(rx, a): return c
    return "??" + a
d = pd.read_csv(src)
d["code"] = d.airport_raw.map(code)
unk = d[d.code.fillna("").str.startswith("??")].airport_raw.unique()
assert len(unk) == 0, unk
d = d.dropna(subset=["code"])
# empty cells in a printed row mean zero traffic in that segment
d[["dom", "intl", "p_dom", "p_intl"]] = d[["dom", "intl", "p_dom", "p_intl"]].fillna(0)
dup = d.groupby(["var", "code", "year", "month"]).size()
assert dup.max() == 1, dup[dup > 1].head()
# YTD for (year, month): prefer the revised value printed as prior-year column in next year's workbook
cur = d[["var", "code", "year", "month", "dom", "intl"]]
rev = d[["var", "code", "year", "month", "p_dom", "p_intl"]].copy()
rev["year"] -= 1; rev = rev.rename(columns={"p_dom": "rdom", "p_intl": "rintl"})
y = cur.merge(rev, on=["var", "code", "year", "month"], how="outer")
# Some workbooks repeat the previous month's cumulative figures (a stale copy). Flag a source/month as
# stale when most airports with passenger traffic show an unchanged YTD total versus the previous month.
def stale(col_d, col_i):
    z = y[(y["var"] == "pax")].sort_values(["code", "year", "month"]).copy()
    z["tot"] = z[col_d] + z[col_i]
    z["prev"] = z.groupby(["code", "year"]).tot.shift(1)
    z = z[(z.month > 1) & (z.prev > 0)]
    share = z.assign(same=(z.tot == z.prev)).groupby(["year", "month"]).same.mean()
    return set(share[share > 0.5].index)
bad_rev, bad_cur = stale("rdom", "rintl"), stale("dom", "intl")
print("stale revised (prior-year column):", sorted(bad_rev)); print("stale current:", sorted(bad_cur))
ym = list(zip(y.year, y.month))
use_rev = np.array([k not in bad_rev for k in ym]) & y.rdom.notna().values
y["ytd_dom"] = np.where(use_rev, y.rdom, y.dom); y["ytd_intl"] = np.where(use_rev, y.rintl, y.intl)
both_bad = np.array([(k in bad_cur) and ((k in bad_rev) or True) for k in ym]) & ~use_rev
y.loc[both_bad, ["ytd_dom", "ytd_intl"]] = np.nan   # no reliable YTD: month left missing
y = y[y.year >= 2009].sort_values(["var", "code", "year", "month"])
for c in ["dom", "intl"]:
    prev = y.groupby(["var", "code", "year"])[f"ytd_{c}"].shift(1).fillna(0)
    y[c] = np.where(y.month == 1, y[f"ytd_{c}"], y[f"ytd_{c}"] - prev)
y["total"] = y.dom + y.intl
neg = y[(y.dom < -0.5) | (y.intl < -0.5)]
print("negative monthly values:", len(neg)); print(neg.groupby("var").size())
neg.to_csv(out.with_name("negative_month_values.csv"), index=False)
p = y.pivot_table(index=["code", "year", "month"], columns="var", values=["dom", "intl", "total"])
p.columns = [f"{v}_{c}" for c, v in p.columns]
p = p.reset_index()
p["date"] = pd.to_datetime(dict(year=p.year, month=p.month, day=1))
p.to_csv(out, index=False)
print(p.shape, p.code.nunique()); print(sorted(p.code.unique()))
