"""Parse every DHMI monthly workbook into a long table of cumulative (year-to-date) values.
Layout (all years): col0 airport, cols1-3 previous-year YTD (dom, intl, total), cols4-6 current-year YTD."""
import sys, re, warnings
import pandas as pd
from pathlib import Path
warnings.filterwarnings("ignore")
raw = Path(sys.argv[1]); out = Path(sys.argv[2])
TR = str.maketrans("İÜÇÖŞĞıüçöşğ", "IUCOSGiucosg")
POS = {0: "all_atm", 1: "pax", 2: "com_atm", 3: "freight"}   # untitled 'SayfaN' workbooks (2009-2012)
def kind(sheet, title, pos):
    t = (sheet + " " + (title if isinstance(title, str) else "")).upper().translate(TR)
    if "YOLCU" in t: return "pax"
    if "TICARI" in t: return "com_atm"
    if "YUK" in t or "BAGAJ" in t: return "freight"
    if "KARGO" in t: return "cargo"
    if "UCAK" in t or sheet.strip().upper().translate(TR) == "TUM": return "all_atm"
    if "SAYFA" in t: return POS.get(pos)
    return None
def num(v):
    try: return float(v)
    except (TypeError, ValueError): return float("nan")
rows, log = [], []
for f in sorted(raw.glob("*.xls*")):
    y, m = map(int, f.stem.split("-"))
    for pos, (sh, df) in enumerate(pd.read_excel(f, sheet_name=None, header=None).items()):
        k = kind(sh, df.iloc[0, 0], pos)
        log.append((f.stem, sh, k))
        if k is None: continue
        for i in range(3, len(df)):
            name = df.iloc[i, 0]
            if not isinstance(name, str): continue
            name = re.sub(r"\s+", " ", name).strip()
            if len(name) < 2 or name.startswith("(") or len(name) > 80: continue
            d, n, pd_, pn = num(df.iloc[i, 4]), num(df.iloc[i, 5]), num(df.iloc[i, 1]), num(df.iloc[i, 2])
            if pd.isna(d) and pd.isna(n): continue
            rows.append(dict(year=y, month=m, var=k, airport_raw=name, dom=d, intl=n, p_dom=pd_, p_intl=pn))
d = pd.DataFrame(rows)
d.to_csv(out, index=False, encoding="utf-8")
lg = pd.DataFrame(log, columns=["file", "sheet", "kind"])
print(d.shape); print(d.groupby("var").size()); print(lg[lg.kind.isna()].to_string())
print(lg.groupby(["kind"]).size())
