"""Download the auxiliary public-domain files used by 04_distances.py and the map figures:
OurAirports airports.csv and Natural Earth 1:50m admin-0 country boundaries."""
from pathlib import Path
import requests
RAW = Path(__file__).resolve().parents[1] / "data" / "raw"
RAW.mkdir(parents=True, exist_ok=True)
FILES = {
    "ourairports_airports.csv": "https://davidmegginson.github.io/ourairports-data/airports.csv",
    "ne_50m_admin0.geojson": "https://raw.githubusercontent.com/nvkelso/natural-earth-vector/master/geojson/ne_50m_admin_0_countries.geojson",
}
for name, url in FILES.items():
    r = requests.get(url, timeout=120, headers={"User-Agent": "research-replication-script"})
    r.raise_for_status()
    (RAW / name).write_bytes(r.content)
    print(name, len(r.content), "bytes")
