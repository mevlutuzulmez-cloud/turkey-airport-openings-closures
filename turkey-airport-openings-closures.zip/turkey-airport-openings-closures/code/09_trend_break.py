"""Long pre-period (48 months) event study and trend-break DiD: adds a stack-specific linear trend
for the exposed group (estimated jointly, identified from the long pre-period), so that the effect
is a break relative to the exposed airports' own relative trend."""
import warnings
import numpy as np, pandas as pd, pyfixest as pf
from importlib import import_module
from common import *
warnings.filterwarnings("ignore")
M = import_module("05_main")
P, T = M.P, M.T
res = []
for kind in ["opening", "closure"]:
    for pre in [24, 48]:
        S = M.stacks(kind, pre=pre)
        d = pd.concat(S)
        d["tt"] = d.rel / 12.0
        d["trend_tr"] = d.treated * d.tt
        for s in d["stack"].unique():
            d[f"tr_{s[:3]}"] = ((d["stack"] == s) & (d.treated == 1)) * d.tt
        trends = " + ".join(f"tr_{s[:3]}" for s in d["stack"].unique())
        dd = add_fe_ids(d)
        for lab, rhs in [("no trend", "D"), ("exposed-group trend by stack", "D + " + trends)]:
            m = pf.feols(f"y ~ {rhs} | fe_unit + fe_time + fe_season", data=dd, vcov={"CRV1": "code"})
            t = m.tidy().loc["D"]
            res.append(dict(kind=kind, pre=pre, spec=lab, coef=t.Estimate, se=t["Std. Error"], p=t["Pr(>|t|)"], nobs=m._N))
            print(res[-1], flush=True)
        if kind == "opening" and pre == 48:
            e = M.event_study(d, "opening"); e.to_csv(OUT / "event_study_opening_pre48.csv", index=False)
            print(e.round(3).T.to_string())
pd.DataFrame(res).to_csv(OUT / "trend_break.csv", index=False)
