"""Tables (markdown + csv) and figures (PNG, 600 dpi) for the manuscript."""
import json, warnings
import numpy as np, pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from importlib import import_module
from common import *
warnings.filterwarnings("ignore")
M = import_module("05_main")
P, T = M.P, M.T
BLUE, ORANGE, GREY, INK, MUTED = "#2a78d6", "#eb6834", "#b9b8b0", "#1f1f1d", "#6b6a64"
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 8.5, "axes.edgecolor": MUTED,
                     "axes.labelcolor": INK, "xtick.color": MUTED, "ytick.color": MUTED,
                     "axes.spines.top": False, "axes.spines.right": False, "axes.grid": True,
                     "grid.color": "#e6e5e0", "grid.linewidth": 0.6, "legend.frameon": False})
NAMES = {"IGD": "Iğdır", "KZR": "Zafer", "NKT": "Şırnak", "BGG": "Bingöl", "KFS": "Kastamonu",
         "OGU": "Ordu-Giresun", "YKO": "Hakkari", "RZV": "Rize-Artvin", "MQM": "Mardin", "DIY": "Diyarbakır",
         "BAL": "Batman", "MZH": "Amasya-Merzifon", "NAV": "Kapadokya", "SZF": "Samsun", "VAN": "Van",
         "TZX": "Trabzon", "KSY": "Kars", "AJI": "Ağrı", "ERZ": "Erzurum", "EZS": "Elazığ", "MSR": "Muş",
         "NOP": "Sinop", "GNY": "Şanlıurfa", "ADF": "Adıyaman", "ASR": "Kayseri", "USQ": "Uşak", "AOE": "Eskişehir"}
nm = lambda c: NAMES.get(c, c)
def save(fig, name):
    fig.savefig(FIG / f"{name}.png", dpi=600, bbox_inches="tight"); plt.close(fig)
def md(df, name, floatfmt=3):
    df.to_csv(OUT / f"{name}.csv", index=False)
    (OUT / f"{name}.md").write_text(df.to_markdown(index=False, floatfmt=f".{floatfmt}f"), encoding="utf-8")

# ---------- Table 1: events ----------
rows = []
for d, fs in M.opening_groups().items():
    for j in fs:
        s = P[(P.code == j) & (P.date >= d) & (P.date < d + pd.DateOffset(months=24))]
        nb = T[j].drop([j]).sort_values()
        rows.append(dict(type="Opening", airport=f"{nm(j)} ({j})", start=f"{d:%Y-%m}", end="",
                         pax_dom_24m=int(s.pax_dom.sum()),
                         nearest_incumbents="; ".join(f"{nm(c)} {int(v)}" for c, v in nb[nb <= 180].items()
                                                      if c not in [x for x, _ in OPENINGS] or c in ["OGU"] and d.year > 2015)))
for j, a, b in CLOSURES:
    a_, b_ = pd.Timestamp(a), pd.Timestamp(b)
    pre = P[(P.code == j) & (P.date >= a_ - pd.DateOffset(months=12)) & (P.date < a_)].pax_dom.mean()
    nb = T[j].drop([j]).sort_values()
    rows.append(dict(type="Closure", airport=f"{nm(j)} ({j})", start=a, end=b, pax_dom_24m=int(pre),
                     nearest_incumbents="; ".join(f"{nm(c)} {int(v)}" for c, v in nb[nb <= 180].items())))
md(pd.DataFrame(rows), "table1_events", 0)

# ---------- Table 2: pooled estimates ----------
pm = pd.read_csv(OUT / "pooled_main.csv"); tb = pd.read_csv(OUT / "trend_break.csv"); pl = pd.read_csv(OUT / "placebo_checks.csv")
t2 = []
for k in ["opening", "closure"]:
    r = pm[(pm.kind == k) & (pm.outcome == "pax_dom")].iloc[0]
    t2.append(dict(design=k, specification="Stacked DiD, 24-month pre-window (main)", coef=r.coef, se=r.se, p=r.p,
                   p_ri=r.p_ri, exposed=int(r.n_treated), controls=int(r.n_control), obs=int(r.nobs)))
    for _, q in tb[tb.kind == k].iterrows():
        if q.pre == 24 and q.spec == "no trend": continue
        t2.append(dict(design=k, specification=f"{'+ exposed-group linear trend by stack' if 'trend' in q.spec and q.spec != 'no trend' else 'No trend'}, {q.pre}-month pre-window",
                       coef=q.coef, se=q.se, p=q.p, p_ri=np.nan, exposed=np.nan, controls=np.nan, obs=int(q.nobs)))
for _, q in pl.iterrows():
    t2.append(dict(design="opening", specification=q.check, coef=q.coef, se=q.se, p=q.p, p_ri=np.nan,
                   exposed=int(q.n_treated), controls=int(q.n_control), obs=int(q.nobs)))
md(pd.DataFrame(t2), "table2_pooled")

# ---------- Table 3: stack-level transfers ----------
st = pd.concat([pd.read_csv(OUT / "stack_transfer_opening.csv"), pd.read_csv(OUT / "stack_transfer_closure.csv")])
sd = pd.read_csv(OUT / "sdid_by_stack.csv")
t3 = st[["kind", "stack", "airports", "months", "coef", "se_placebo", "p_placebo", "focal_pax", "moved", "ratio", "ci_lo", "ci_hi"]].copy()
t3 = t3.merge(sd[["stack", "sdid", "se_placebo", "ratio"]].rename(columns={"se_placebo": "sdid_se", "ratio": "sdid_ratio"}), on="stack", how="left")
t3["airports"] = t3.airports.map(lambda s: ", ".join(nm(c) for c in s.split(",")))
md(t3, "table3_stacks")
# pooled ratios: (i) sum of moved / sum of focal; (ii) inverse-variance weighted mean of stack ratios
pr = []
for k, g in t3.groupby("kind"):
    se = (g.ci_hi - g.ci_lo) / 3.92; w = 1 / se ** 2
    pr.append(dict(kind=k, aggregate_ratio=g.moved.sum() / g.focal_pax.sum(),
                   ivw_ratio=(w * g.ratio).sum() / w.sum(), ivw_se=np.sqrt(1 / w.sum()),
                   sdid_aggregate=np.nan))
pr = pd.DataFrame(pr)
for k in ["opening", "closure"]:
    g = sd[sd.kind == k]; pr.loc[pr.kind == k, "sdid_aggregate"] = g.moved.sum() / g.focal_pax.sum()
# diversion implied by pooled opening coefficients (main, trend-break)
op = pd.concat([pd.read_csv(OUT / "stacked_opening.csv")])
expo = st[st.kind == "opening"].exposed_pax.sum(); foc = st[st.kind == "opening"].focal_pax.sum()
imp = []
for lab, b, s in [("main", pm.query("kind=='opening' & outcome=='pax_dom'").coef.iloc[0], pm.query("kind=='opening' & outcome=='pax_dom'").se.iloc[0]),
                  ("trend-break (24m)", tb.query("kind=='opening' & pre==24 & spec!='no trend'").coef.iloc[0], tb.query("kind=='opening' & pre==24 & spec!='no trend'").se.iloc[0])]:
    f = lambda bb: expo * (np.exp(-bb) - 1) / foc
    imp.append(dict(spec=lab, coef=b, diversion=f(b), lo=f(b + 1.96 * s), hi=f(b - 1.96 * s)))
ce = st[st.kind == "closure"]; cexp = ce.exposed_pax.sum(); cfoc = ce.focal_pax.sum()
for lab, b, s in [("closure main", pm.query("kind=='closure' & outcome=='pax_dom'").coef.iloc[0], pm.query("kind=='closure' & outcome=='pax_dom'").se.iloc[0]),
                  ("closure trend-break (24m)", tb.query("kind=='closure' & pre==24 & spec!='no trend'").coef.iloc[0], tb.query("kind=='closure' & pre==24 & spec!='no trend'").se.iloc[0])]:
    f = lambda bb: cexp * (1 - np.exp(-bb)) / cfoc
    imp.append(dict(spec=lab, coef=b, diversion=f(b), lo=f(b - 1.96 * s), hi=f(b + 1.96 * s)))
md(pr, "table3b_aggregate_ratios"); md(pd.DataFrame(imp), "table3c_implied_ratios")
print(pr.round(3).to_string()); print(pd.DataFrame(imp).round(3).to_string())

# ---------- Table 4: robustness ----------
rb = pd.read_csv(OUT / "robustness_pooled.csv")[["kind", "spec", "coef", "se", "p", "n_treated", "n_control", "nobs"]]
md(rb, "table4_robustness")
md(pd.read_csv(OUT / "distance_bands.csv")[["kind", "band", "coef", "se", "p", "n_treated", "n_control"]], "table5_distance_bands")
ue = pd.concat([pd.read_csv(OUT / "unit_effects_opening.csv"), pd.read_csv(OUT / "unit_effects_closure.csv")])
ue["airport"] = ue.code.map(nm)
md(ue[["kind", "stack", "airport", "rt", "pre_mean", "coef", "se_placebo", "p_placebo", "pax_moved"]], "tableA1_airport_effects")

# ---------- Figure 1: map ----------
geo = json.load(open(DATA / "raw" / "ne_50m_admin0.geojson", encoding="utf-8"))
tur = [f for f in geo["features"] if f["properties"]["ADMIN"] == "Turkey"][0]["geometry"]
co = pd.read_csv(DATA / "airports_coords.csv").set_index("code")
fig, ax = plt.subplots(figsize=(7.2, 3.6))
polys = tur["coordinates"] if tur["type"] == "MultiPolygon" else [tur["coordinates"]]
for poly in polys:
    xy = np.array(poly[0]); ax.fill(xy[:, 0], xy[:, 1], color="#f3f2ee", ec=GREY, lw=0.6, zorder=0)
op_codes = [j for j, _ in OPENINGS]; cl_codes = [j for j, _, _ in CLOSURES]
oth = co.drop(op_codes + cl_codes, errors="ignore")
ax.scatter(oth.lon, oth.lat, s=9, c=MUTED, zorder=2, label="Other airports (DHMİ panel)")
ax.scatter(co.loc[op_codes].lon, co.loc[op_codes].lat, s=34, marker="^", c=BLUE, ec="white", lw=0.6, zorder=3, label="Opening (2012–2022)")
ax.scatter(co.loc[cl_codes].lon, co.loc[cl_codes].lat, s=30, marker="s", c=ORANGE, ec="white", lw=0.6, zorder=3, label="Temporary closure")
off = {"IGD": (4, 3), "KZR": (4, -8), "NKT": (2, -9), "BGG": (-10, 6), "KFS": (-8, 6), "OGU": (-12, 6), "YKO": (4, -7),
       "RZV": (4, 4), "MQM": (-22, -8), "DIY": (-26, 3), "BAL": (2, 5), "MZH": (-20, -9), "NAV": (-12, -9), "SZF": (2, 5), "VAN": (-14, 5)}
for c in op_codes + cl_codes:
    ax.annotate(nm(c), (co.loc[c].lon, co.loc[c].lat), xytext=off.get(c, (3, 3)), textcoords="offset points", fontsize=6.5, color=INK)
ax.set_xlim(25.5, 45); ax.set_ylim(35.7, 42.3); ax.set_aspect(1.25); ax.grid(False)
ax.set_xticks([]); ax.set_yticks([]); [s.set_visible(False) for s in ax.spines.values()]
ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.01), ncol=3, fontsize=7, markerscale=1)
save(fig, "fig1_map")

# ---------- Figure 2: event studies ----------
fig, axs = plt.subplots(1, 3, figsize=(7.6, 2.8), gridspec_kw=dict(width_ratios=[1, 1.5, 1.1], wspace=0.35))
for ax, f, col, mk, xl, title in [
        (axs[0], "event_study_opening.csv", BLUE, "o", "Quarters relative to opening", "(a) Openings: 24-month pre"),
        (axs[1], "event_study_opening_pre48.csv", BLUE, "o", "Quarters relative to opening", "(b) Openings: 48-month pre"),
        (axs[2], "event_study_closure.csv", ORANGE, "s", "Months relative to closure start", "(c) Closures")]:
    e = pd.read_csv(OUT / f).dropna()
    ax.axhline(0, color=MUTED, lw=0.8); ax.axvline(-0.5, color=MUTED, lw=0.8, ls=":")
    ax.errorbar(e.bin, e.coef, yerr=1.96 * e.se, fmt=mk, ms=3.5, color=col, ecolor=col, elinewidth=1, capsize=0)
    ax.set_xlabel(xl); ax.set_title(title, fontsize=8, loc="left", color=INK)
axs[0].set_ylabel("Effect on log domestic passengers")
save(fig, "fig2_event_studies")

# ---------- Figure 3: forest plot of ratios ----------
f3 = t3.copy()
f3["label"] = f3.apply(lambda r: ("Opening: " if r.kind == "opening" else "Closure: ") +
                       " + ".join(nm(c) for c in r.stack.split("-")[0].split("+")) + f" ({r.stack.split('-')[1][:4]})", axis=1)
f3 = f3.sort_values(["kind", "stack"], ascending=[False, True]).reset_index(drop=True)
fig, ax = plt.subplots(figsize=(6.4, 3.9))
y = np.arange(len(f3))[::-1]
for yi, (_, r) in zip(y, f3.iterrows()):
    col, mk = (BLUE, "o") if r.kind == "opening" else (ORANGE, "s")
    lo, hi = max(r.ci_lo, -1.5), min(r.ci_hi, 2.5)
    ax.plot([lo, hi], [yi, yi], color=col, lw=1.2)
    if r.ci_hi > 2.5: ax.annotate("", (2.55, yi), (2.35, yi), arrowprops=dict(arrowstyle="-|>", color=col, lw=1))
    if r.ci_lo < -1.5: ax.annotate("", (-1.55, yi), (-1.35, yi), arrowprops=dict(arrowstyle="-|>", color=col, lw=1))
    ax.plot(r.ratio, yi, mk, color=col, ms=5, zorder=3)
    if pd.notna(r.sdid_ratio): ax.plot(r.sdid_ratio, yi, "D", mfc="white", mec=col, ms=4, zorder=4)
ax.axvline(0, color=MUTED, lw=0.8); ax.axvline(1, color=MUTED, lw=0.8, ls=":")
ax.set_yticks(y); ax.set_yticklabels(f3.label, fontsize=7.5); ax.grid(axis="y", visible=False)
ax.set_xlim(-1.6, 2.6)
ax.set_xlabel("Passengers moved to/from neighbours ÷ new airport traffic (openings) or lost traffic (closures)")
ax.plot([], [], "o", color=MUTED, label="Stacked DiD (95% placebo interval)"); ax.plot([], [], "D", mfc="white", mec=MUTED, label="Synthetic DiD")
ax.legend(loc="lower right", fontsize=7)
save(fig, "fig3_ratios")

# ---------- Figure 4: illustrative series ----------
fig, axs = plt.subplots(1, 2, figsize=(7.4, 2.7))
w = P.pivot_table(index="date", columns="code", values="pax_dom") / 1e3
a = w.loc["2011-06":"2013-06", ["DIY", "BAL", "MQM"]]
for c, col, ls in [("DIY", MUTED, "-"), ("BAL", ORANGE, "-"), ("MQM", ORANGE, "--")]:
    axs[0].plot(a.index, a[c], color=col, ls=ls, lw=1.6); axs[0].annotate(nm(c), (a.index[-1], a[c].iloc[-1]), xytext=(3, 6 if c == "BAL" else (-4 if c == "MQM" else 0)), textcoords="offset points", fontsize=7, color=INK, va="center")
axs[0].axvspan(pd.Timestamp("2012-06-01"), pd.Timestamp("2012-08-31"), color="#f3f2ee", zorder=0)
axs[0].set_title("(a) Diyarbakır closure, Jun–Aug 2012", fontsize=8, loc="left"); axs[0].set_ylabel("Domestic passengers (000s/month)")
b = w.loc["2018-01":"2026-10", ["TZX", "RZV"]].copy()
b.loc["2020-03":"2021-06"] = np.nan
b.loc[:"2022-04", "RZV"] = np.nan
for c, col in [("TZX", MUTED), ("RZV", BLUE)]:
    axs[1].plot(b.index, b[c], color=col, lw=1.4); axs[1].annotate(nm(c), (b.index[-1], b[c].iloc[-1]), xytext=(3, 0), textcoords="offset points", fontsize=7, color=INK, va="center")
axs[1].axvline(pd.Timestamp("2022-05-01"), color=MUTED, ls=":", lw=0.9)
axs[1].set_title("(b) Rize-Artvin opening, May 2022 (COVID-19 months omitted)", fontsize=8, loc="left")
import matplotlib.dates as mdates
axs[0].xaxis.set_major_locator(mdates.MonthLocator(bymonth=[1, 7])); axs[0].xaxis.set_major_formatter(mdates.DateFormatter("%b %Y"))
axs[1].xaxis.set_major_locator(mdates.YearLocator(2)); axs[1].xaxis.set_major_formatter(mdates.DateFormatter("%Y"))
for ax in axs: ax.tick_params(axis="x", labelsize=7)
fig.tight_layout(); save(fig, "fig4_series")

# ---------- Figure 5: distance gradient ----------
db = pd.read_csv(OUT / "distance_bands.csv")
fig, ax = plt.subplots(figsize=(4.2, 2.7))
xs = np.arange(4)
for k, col, mk, dx in [("opening", BLUE, "o", -0.08), ("closure", ORANGE, "s", 0.08)]:
    g = db[db.kind == k]
    ax.errorbar(xs + dx, g.coef, yerr=1.96 * g.se, fmt=mk, color=col, ms=4.5, elinewidth=1, capsize=0, label="Openings" if k == "opening" else "Closures")
ax.axhline(0, color=MUTED, lw=0.8); ax.set_xticks(xs); ax.set_xticklabels(["0–120", "120–180", "180–240", "240–300"])
ax.set_xlabel("Road travel time to the opened/closed airport (min)"); ax.set_ylabel("Effect on log domestic passengers")
ax.legend(fontsize=7, loc="upper right")
save(fig, "fig5_distance")
print("done")
