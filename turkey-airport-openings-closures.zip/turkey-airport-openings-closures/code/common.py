"""Shared definitions: panel loading, event lists, stacked-sample construction."""
from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATA, OUT, FIG = ROOT / "data", ROOT / "output", ROOT / "figures"
OUT.mkdir(exist_ok=True); FIG.mkdir(exist_ok=True)

HUBS = ["IST", "ISL", "SAW", "ESB", "ADB", "AYT"]          # national/international gateways
RELOCATIONS = ["COV", "ADA"]                                  # Adana -> Cukurova relocation (2024)
COVID = (pd.Timestamp("2020-03-01"), pd.Timestamp("2021-06-01"))

# Greenfield openings of commercial airports with scheduled service (first month > 1,000 pax).
OPENINGS = [
    ("IGD", "2012-07"), ("KZR", "2012-11"), ("NKT", "2013-07"), ("BGG", "2013-07"),
    ("KFS", "2013-07"), ("OGU", "2015-08"), ("YKO", "2015-08"), ("RZV", "2022-05"),
]
# Temporary closures (first and last closed month, inclusive) identified from the series:
# traffic below 15% of the trailing 12-month median for >= 2 consecutive months,
# excluding COVID-19 (2020), the 2023 earthquake (HTY), seasonal winter closures (DLM),
# and closed airports below 10,000 monthly passengers (analysed events).
CLOSURES = [
    ("MQM", "2011-07", "2012-02"), ("DIY", "2012-06", "2012-08"), ("BAL", "2015-06", "2015-11"),
    ("MZH", "2016-06", "2016-10"), ("NAV", "2017-05", "2017-10"), ("SZF", "2017-08", "2017-10"),
    ("VAN", "2025-09", "2025-11"),
]
# Closures of very small airports: not analysed, but they contaminate neighbouring airport-months.
CLOSURES_SMALL = [("ADF", "2011-07", "2011-12"), ("NOP", "2013-01", "2013-07"),
                  ("TJK", "2017-05", "2022-02"),  # Tokat closed, replaced by a new airport on a new site
                  ("SXZ", "2017-05", "2017-10"), ("HTY", "2023-02", "2023-10"), ("BAL", "2023-09", "2023-09")]


def load_panel():
    p = pd.read_csv(DATA / "panel_airport_month.csv", parse_dates=["date"])
    p = p[["code", "date", "pax_dom", "pax_intl", "pax_total", "com_atm_dom", "com_atm_total"]].copy()
    p = p[p.date >= "2010-01-01"]                       # 2009 workbooks are internally inconsistent
    cols = ["pax_dom", "pax_intl", "pax_total", "com_atm_dom", "com_atm_total"]
    p[cols] = p[cols].mask(p[cols] < 0)                 # negative monthly differences -> missing
    return p


def road_time():
    return pd.read_csv(DATA / "road_time_min.csv", index_col=0)


def months_between(a, b):
    return (b.year - a.year) * 12 + (b.month - a.month)


def shock_table():
    rows = []
    for j, d in OPENINGS:
        rows.append(dict(kind="opening", focal=j, start=pd.Timestamp(d), end=pd.Timestamp("2099-01-01")))
    for j, a, b in CLOSURES + CLOSURES_SMALL:
        rows.append(dict(kind="closure", focal=j, start=pd.Timestamp(a), end=pd.Timestamp(b)))
    return pd.DataFrame(rows)


def build_stack(focals, start, end, kind, panel, T, *, outcome="pax_dom", r_treat=180, r_control=300,
                r_contam=180, pre=None, post=24, min_size=5000, exclude_hubs=True, drop_buffer=True,
                drop_months=None, after=0, keep_focal=False):
    """Airport-month sample for one shock (a stack). `focals` is a list of airports that open
    (or close) at the same date; exposure is the road time to the nearest focal airport.

    Treated: incumbents with road time <= r_treat. Controls: road time > r_control.
    Airport-months are dropped when the airport itself is closed, or when another shock
    (an opening inside the window, or an active closure) hits an airport within r_control of it.
    """
    focals = list(focals)
    shocks = shock_table()
    if pre is None:
        pre = 24
    w0 = start - pd.DateOffset(months=pre)
    w1 = start + pd.DateOffset(months=post - 1) if kind == "opening" else end + pd.DateOffset(months=after)
    d = panel[(panel.date >= w0) & (panel.date <= w1)].copy()
    d = d[~d.code.isin((focals if not keep_focal else []) + RELOCATIONS + (HUBS if exclude_hubs else []))]
    d = d[~((d.date >= COVID[0]) & (d.date <= COVID[1]))]
    d["rt"] = d.code.map(T[focals].min(axis=1))
    if drop_buffer:
        d = d[(d.rt <= r_treat) | (d.rt > r_control)]
    d["focal"] = d.code.isin(focals).astype(int)
    if keep_focal:
        d.loc[d.focal == 1, "rt"] = 0
    d["treated"] = ((d.rt <= r_treat) & (d.focal == 0)).astype(int)
    keep = np.ones(len(d), bool)
    for s in shocks.itertuples():
        if s.focal in focals and s.start == start and s.kind == kind:
            continue
        near = (d.code.map(T[s.focal]) <= r_contam).values
        own = (d.code == s.focal).values
        if s.kind == "closure":
            active = ((d.date >= s.start) & (d.date <= s.end)).values
            keep &= ~((near | own) & active)
        else:
            if s.start > w0:            # opened inside or after the window: not an incumbent
                keep &= ~own
            if w0 < s.start <= start:   # earlier opening nearby: keep only the new steady state
                keep &= ~(near & (d.date < s.start).values)
            elif start < s.start <= w1: # later opening nearby: drop months from that opening on
                keep &= ~(near & (d.date >= s.start).values)
    d = d[keep]
    if drop_months is not None:          # optional: [(codes, first, last), ...] airport-months to drop
        for codes, a, b in ([drop_months] if isinstance(drop_months, tuple) else drop_months):
            d = d[~(d.code.isin(codes) & (d.date >= pd.Timestamp(a)) & (d.date <= pd.Timestamp(b)))]
    prew = d[d.date < start]
    size = prew.groupby("code")[outcome].mean()
    d = d[d.code.isin(size[size >= min_size].index)]
    d = d[(d[outcome] > 0) | ((d.focal == 1) & d[outcome].notna())]
    d["rel"] = d.date.map(lambda x: months_between(start, x))
    if kind == "opening":
        d["post"] = (d.date >= start).astype(int)
    else:
        d["post"] = ((d.date >= start) & (d.date <= end)).astype(int)
    d["after"] = (d.date > end).astype(int) if kind == "closure" else 0
    d["D"] = d.treated * d.post
    d["y"] = np.log(d[outcome].where(d[outcome] > 0))
    d["moy"] = d.date.dt.month
    d["stack"] = "+".join(focals) + f"-{start:%Y%m}"
    d["kind"] = kind
    return d


def add_fe_ids(d):
    d = d.copy()
    d["fe_unit"] = d["stack"] + "_" + d["code"]
    d["fe_time"] = d["stack"] + "_" + d.date.dt.strftime("%Y%m")
    d["fe_season"] = d.fe_unit + "_" + d.moy.astype(str)
    return d
