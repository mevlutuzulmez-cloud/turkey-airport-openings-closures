"""Robustness of the pooled stacked estimates and spatial gradient (distance bands)."""
import warnings
import numpy as np, pandas as pd
from importlib import import_module
from common import *
warnings.filterwarnings("ignore")
M = import_module("05_main")
P, T = M.P, M.T


def pooled_from(S):
    d = pd.concat([s for s in S if s.treated.sum() > 0])
    m = M.fit(d); t = m.tidy().loc["D"]
    return dict(coef=t.Estimate, se=t["Std. Error"], p=t["Pr(>|t|)"],
                n_treated=d[d.treated == 1].drop_duplicates(["stack", "code"]).shape[0],
                n_control=d[d.treated == 0].drop_duplicates(["stack", "code"]).shape[0], nobs=m._N)


def stacks(kind, **kw):
    return M.stacks(kind, **kw)


def detrended(kind, **kw):
    """Remove each airport's linear trend (and month-of-year profile) fitted on pre-event months."""
    out = []
    for g in stacks(kind, **kw):
        g = g.copy(); start = g[g.post == 1].date.min()
        g["t"] = (g.date.dt.year - start.year) * 12 + g.date.dt.month - start.month
        res = []
        for c, h in g.groupby("code"):
            pre = h[h.date < start]
            X = np.column_stack([np.ones(len(pre)), pre.t] + [(pre.moy == k).astype(float) for k in range(2, 13)])
            b = np.linalg.lstsq(X, pre.y.values, rcond=None)[0]
            Xa = np.column_stack([np.ones(len(h)), h.t] + [(h.moy == k).astype(float) for k in range(2, 13)])
            h = h.copy(); h["y"] = h.y - Xa @ b; res.append(h)
        out.append(pd.concat(res))
    return out


rows = []
def add(kind, label, S=None, **kw):
    r = pooled_from(S if S is not None else stacks(kind, **kw))
    r.update(kind=kind, spec=label); rows.append(r)
    print(kind, label, {k: round(v, 4) if isinstance(v, float) else v for k, v in r.items() if k not in ("kind", "spec")}, flush=True)


for kind in ["opening", "closure"]:
    add(kind, "Main: domestic pax, 180 min, controls >300 min")
    add(kind, "Total pax (domestic + international)", outcome="pax_total")
    add(kind, "Domestic commercial flights", outcome="com_atm_dom", min_size=50)
    add(kind, "Exposure radius 150 min", r_treat=150)
    add(kind, "Exposure radius 210 min", r_treat=210)
    add(kind, "Controls beyond 240 min", r_control=240)
    add(kind, "Hub airports kept as controls", exclude_hubs=False)
    add(kind, "Small airports kept (min. 1,000 pax/month)", min_size=1000)
    add(kind, "Airport-specific pre-event linear trends", S=detrended(kind))
    if kind == "opening":
        add(kind, "Post window 36 months", post=36)
        add(kind, "Post window 12 months", post=12)
        for d, fs in M.opening_groups().items():
            S = [s for s in stacks(kind) if not s["stack"].iloc[0].startswith("+".join(fs))]
            add(kind, f"Leave out {'+'.join(fs)} ({d:%Y-%m})", S=S)
    else:
        for j, a, b in CLOSURES:
            S = [s for s in stacks(kind) if not s["stack"].iloc[0].startswith(j)]
            add(kind, f"Leave out {j} ({a})", S=S)
R = pd.DataFrame(rows)
R.to_csv(OUT / "robustness_pooled.csv", index=False)

# Spatial gradient: exposure bands, each band compared with the same far controls (>300 min)
bands = [(0, 120), (120, 180), (180, 240), (240, 300)]
G = []
for kind in ["opening", "closure"]:
    for lo, hi in bands:
        S = []
        for s in stacks(kind, r_treat=300, r_control=300):
            s = s[(s.treated == 0) | ((s.rt > lo) & (s.rt <= hi))]
            S.append(s)
        r = pooled_from(S); r.update(kind=kind, band=f"{lo}-{hi}"); G.append(r)
        print(kind, lo, hi, round(r["coef"], 3), round(r["se"], 3), r["n_treated"], flush=True)
pd.DataFrame(G).to_csv(OUT / "distance_bands.csv", index=False)
