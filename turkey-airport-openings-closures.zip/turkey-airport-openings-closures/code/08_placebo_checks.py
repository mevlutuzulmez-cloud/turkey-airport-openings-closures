"""Checks for regional confounding in the opening design:
(1) time placebo: openings moved 24 months earlier, sample truncated before the true opening;
(2) event study for airports 240-300 min away from the new airport;
(3) which airports form the 240-300 min band."""
import warnings
import numpy as np, pandas as pd
from importlib import import_module
from common import *
warnings.filterwarnings("ignore")
M = import_module("05_main"); R = import_module("07_robustness")
P, T = M.P, M.T
out = []
# (1) time placebo
S = []
for d, fs in M.opening_groups().items():
    fake = d - pd.DateOffset(months=24)
    s = build_stack(fs, fake, None, "opening", P, T, pre=24, post=24)
    s = s[s.date < d]                          # never use months after the real opening
    S.append(s)
r = R.pooled_from(S); r["check"] = "Time placebo: openings 24 months earlier"; out.append(r); print(r)
# (2) far band event study and pooled
S = []
for s in M.stacks("opening", r_treat=300, r_control=300):
    S.append(s[(s.treated == 0) | ((s.rt > 240) & (s.rt <= 300))])
d = pd.concat(S)
print(d[d.treated == 1].groupby("stack").code.unique())
e = M.event_study(d, "opening"); e.to_csv(OUT / "event_study_opening_band240_300.csv", index=False)
print(e.round(3).T.to_string())
# (3) placebo for far band in time
S = []
for dd, fs in M.opening_groups().items():
    fake = dd - pd.DateOffset(months=24)
    s = build_stack(fs, fake, None, "opening", P, T, r_treat=300, r_control=300)
    s = s[(s.date < dd) & ((s.treated == 0) | ((s.rt > 240) & (s.rt <= 300)))]
    S.append(s)
r = R.pooled_from(S); r["check"] = "Time placebo, 240-300 min band"; out.append(r); print(r)
pd.DataFrame(out).to_csv(OUT / "placebo_checks.csv", index=False)
