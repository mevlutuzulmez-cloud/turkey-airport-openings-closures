# Data sources and licences

The code in this repository is released under the MIT License (see `LICENSE`). The data files have the following origins and terms.

| File(s) | Content | Source | Terms |
|---|---|---|---|
| `data/panel_airport_month.csv`, `data/interim_ytd_long.csv` | Monthly passengers, aircraft movements and freight by airport, 2009/2010–2026 | Derived from the monthly statistics published by DHMİ (State Airports Authority of Türkiye), https://www.dhmi.gov.tr/Sayfalar/Istatistikler.aspx | Processed data released under CC BY 4.0. Users must also cite DHMİ as the original source. The original DHMİ workbooks are not redistributed; `code/00_list_dhmi.py` and `code/01_download_dhmi.py` retrieve them from DHMİ. |
| `data/raw/dhmi_index.json` | List of DHMİ workbook URLs by year and month | DHMİ website | As above |
| `data/airports_coords.csv` | Airport coordinates | OurAirports, https://ourairports.com/data/ | Public domain |
| `data/road_time_min.csv`, `data/road_dist_km.csv` | Road travel times and distances between airports | Computed with OSRM (https://project-osrm.org) on OpenStreetMap data | © OpenStreetMap contributors. Available under the Open Database License (ODbL) 1.0, https://opendatacommons.org/licenses/odbl/ |
| `data/dist_greatcircle_km.csv` | Great-circle distances between airports | Computed from OurAirports coordinates | Public domain |
| `data/events.csv` | Event definitions (openings, closures, exclusions) | Author | CC BY 4.0 |
| `output/*.csv`, `figures/*.png` | Estimation results and figures | Author | CC BY 4.0 |
| Map boundaries (downloaded by `code/00b_download_aux.py`) | Country boundaries | Natural Earth, https://www.naturalearthdata.com | Public domain |

CC BY 4.0: https://creativecommons.org/licenses/by/4.0/
